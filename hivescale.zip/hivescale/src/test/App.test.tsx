import { render, screen, within, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import App from '../App';

function panel() {
  return screen.getByRole('region', { name: 'Recommendation' });
}
function type(label: RegExp, value: string) {
  const input = screen.getByLabelText(label);
  fireEvent.change(input, { target: { value } });
  return input;
}
function fillCostCap(bid = '100', spend = '650', conv = '10') {
  type(/Current Cost Cap bid/, bid);
  type(/Actual budget consumption/, spend);
  type(/^Conversions/, conv);
}
function checkAll() {
  const list = screen.getByRole('region', { name: 'Best-practice checks' });
  within(list)
    .getAllByRole('checkbox')
    .forEach((cb) => {
      if (!(cb as HTMLInputElement).checked) fireEvent.click(cb);
    });
}

beforeEach(() => {
  vi.useRealTimers();
});
afterEach(() => {
  vi.restoreAllMocks();
});

describe('live calculation', () => {
  it('starts incomplete with no recommendation', () => {
    render(<App />);
    expect(within(panel()).getByTestId('readiness')).toHaveTextContent('Incomplete');
    expect(within(panel()).getByTestId('empty-state')).toBeInTheDocument();
    expect(within(panel()).getByRole('button', { name: /Copy summary/ })).toBeDisabled();
  });

  it('recalculates on every change without a Calculate button', () => {
    render(<App />);
    fillCostCap();
    expect(within(panel()).getByTestId('billing-ratio')).toHaveTextContent('0.65');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('DECREASE');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹80.00');

    type(/Actual budget consumption/, '1500');
    expect(within(panel()).getByTestId('billing-ratio')).toHaveTextContent('1.50');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('INCREASE');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹120.00');

    type(/Actual budget consumption/, '800');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('MAINTAIN');
    expect(screen.queryByRole('button', { name: /^Calculate$/ })).not.toBeInTheDocument();
  });

  it('hides stale results when input becomes invalid', () => {
    render(<App />);
    fillCostCap();
    type(/^Conversions/, '0');
    expect(within(panel()).queryByTestId('recommended-bid')).not.toBeInTheDocument();
    expect(within(panel()).getByTestId('readiness')).toHaveTextContent('Invalid');
    expect(screen.getAllByText(/zero conversions/i).length).toBeGreaterThan(0);
    type(/^Conversions/, '2.5');
    expect(screen.getAllByText(/whole number/i).length).toBeGreaterThan(0);
  });

  it('never shows NaN, Infinity or undefined', () => {
    render(<App />);
    fillCostCap('abc', '-1', '0');
    expect(document.body.textContent).not.toMatch(/NaN|Infinity|undefined/);
  });
});

describe('checklist readiness', () => {
  it('moves from provisional to ready', () => {
    render(<App />);
    fillCostCap();
    expect(within(panel()).getByTestId('readiness')).toHaveTextContent('Provisional');
    expect(within(panel()).getByText('Provisional: Complete best-practice checks first.')).toBeInTheDocument();
    checkAll();
    expect(within(panel()).getByTestId('readiness')).toHaveTextContent('Ready for review');
  });
});

describe('mode switching', () => {
  it('keeps each mode independent and changes labels and rules', async () => {
    const user = userEvent.setup();
    render(<App />);
    fillCostCap();
    await user.click(screen.getByRole('radio', { name: /tROAS/ }));
    expect(screen.queryByLabelText(/Current Cost Cap bid/)).not.toBeInTheDocument();
    expect(within(panel()).getByTestId('readiness')).toHaveTextContent('Incomplete');

    type(/Current minimum ROAS bid/, '2');
    type(/Achieved ROAS/, '4');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('INCREASE');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('2.40x');

    await user.click(screen.getByRole('radio', { name: /Cost Cap/ }));
    expect(screen.getByLabelText(/Current Cost Cap bid/)).toHaveValue('100');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('DECREASE');
  });

  it('converts ROAS values when switching display format', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('radio', { name: /tROAS/ }));
    type(/Current minimum ROAS bid/, '2.7');
    type(/Achieved ROAS/, '2');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('2.16x');
    await user.click(screen.getByRole('radio', { name: /Percentage/ }));
    expect(screen.getByLabelText(/Current minimum ROAS bid/)).toHaveValue('270');
    expect(screen.getByLabelText(/Achieved ROAS/)).toHaveValue('200');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('216%');
    expect(within(panel()).getByTestId('billing-ratio')).toHaveTextContent('1.35');
  });
});

describe('breakdown, limits and simulations', () => {
  it('breakdown reproduces the displayed result', async () => {
    const user = userEvent.setup();
    render(<App />);
    fillCostCap();
    await user.click(screen.getByRole('button', { name: 'How was this calculated?' }));
    const steps = screen.getByTestId('breakdown');
    expect(steps).toHaveTextContent('₹650.00 ÷ (₹100.00 × 10)');
    expect(steps).toHaveTextContent('₹100.00 × 0.80');
    expect(steps).toHaveTextContent('₹80.00');
  });

  it('applies bid limits transparently', () => {
    render(<App />);
    fillCostCap('100', '1500', '10');
    type(/^Maximum bid/, '110');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹110.00');
    expect(within(panel()).getByText(/Bid limit applied/)).toBeInTheDocument();
    const status = screen.getByTestId('limit-status');
    expect(status).toHaveTextContent('Official rule result₹120.00');
    expect(status).toHaveTextContent('Final proposed bid₹110.00');
    type(/^Minimum bid/, '200');
    expect(screen.getByText(/Maximum bid must be greater than or equal/)).toBeInTheDocument();
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹120.00');
  });

  it('simulations never overwrite the official recommendation', async () => {
    const user = userEvent.setup();
    render(<App />);
    fillCostCap('100', '1500', '10');
    await user.click(screen.getByRole('button', { name: '15%' }));
    const sim = screen.getByTestId('simulation');
    expect(sim).toHaveTextContent('What-if: increase by 15%');
    expect(sim).toHaveTextContent('₹115.00');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹120.00');
    // Bid 200 → ratio 0.75 → official action flips to decrease; the what-if follows it.
    type(/Current Cost Cap bid/, '200');
    expect(screen.getByTestId('simulation')).toHaveTextContent('What-if: decrease by 15%₹170.00');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹160.00');
    // A manual direction choice sticks.
    await user.click(screen.getByRole('radio', { name: 'Increase' }));
    expect(screen.getByTestId('simulation')).toHaveTextContent('₹230.00');
    expect(within(panel()).getByTestId('recommended-bid')).toHaveTextContent('₹160.00');
  });
});

describe('copy, export, print, reset and history', () => {
  it('copies a summary to the clipboard', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', { value: { writeText }, configurable: true });
    render(<App />);
    type(/Campaign name/, 'IN Remit');
    fillCostCap();
    fireEvent.click(within(panel()).getByRole('button', { name: /Copy summary/ }));
    await screen.findByText('Recommendation copied');
    const text = writeText.mock.calls[0][0] as string;
    expect(text).toContain('Campaign: IN Remit');
    expect(text).toContain('Recommended bid: ₹80.00');
  });

  it('exports a CSV download', async () => {
    const create = vi.fn(() => 'blob:x');
    const revoke = vi.fn();
    Object.assign(URL, { createObjectURL: create, revokeObjectURL: revoke });
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});
    render(<App />);
    fillCostCap();
    fireEvent.click(within(panel()).getByRole('button', { name: /Export CSV/ }));
    expect(create).toHaveBeenCalledOnce();
    expect(click).toHaveBeenCalledOnce();
    const blob = (create.mock.calls[0] as unknown as [Blob])[0];
    const text = await new Promise<string>((res) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result));
      fr.readAsText(blob);
    });
    expect(text).toContain('Billing ratio');
    expect(text).toContain('DECREASE');
  });

  it('prints with a print header', async () => {
    vi.useFakeTimers();
    const print = vi.fn();
    window.print = print;
    render(<App />);
    fillCostCap();
    fireEvent.click(within(panel()).getByRole('button', { name: /Print/ }));
    vi.runAllTimers();
    expect(print).toHaveBeenCalledOnce();
    expect(document.querySelector('.print-head')).toHaveTextContent('HiveScale bid recommendation');
  });

  it('asks before resetting entered data, then clears the current mode only', async () => {
    const user = userEvent.setup();
    render(<App />);
    fillCostCap();
    await user.click(screen.getByRole('radio', { name: /tROAS/ }));
    type(/Current minimum ROAS bid/, '2');
    await user.click(screen.getByRole('radio', { name: /Cost Cap/ }));
    await user.click(screen.getByRole('button', { name: /Reset Cost Cap/ }));
    const dialog = screen.getByRole('alertdialog');
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }));
    expect(screen.getByLabelText(/Current Cost Cap bid/)).toHaveValue('100');
    await user.click(screen.getByRole('button', { name: /Reset Cost Cap/ }));
    await user.click(within(screen.getByRole('alertdialog')).getByRole('button', { name: 'Reset calculator' }));
    expect(screen.getByLabelText(/Current Cost Cap bid/)).toHaveValue('');
    await user.click(screen.getByRole('radio', { name: /tROAS/ }));
    expect(screen.getByLabelText(/Current minimum ROAS bid/)).toHaveValue('2');
  });

  it('resets an empty calculator without asking', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('button', { name: /Reset Cost Cap/ }));
    expect(screen.queryByRole('alertdialog')).not.toBeInTheDocument();
  });

  it('saves, reopens and clears session history', async () => {
    const user = userEvent.setup();
    render(<App />);
    type(/Campaign name/, 'Alpha');
    fillCostCap();
    await user.click(within(panel()).getByRole('button', { name: /Save to history/ }));
    const history = screen.getByRole('region', { name: 'Session history' });
    expect(within(history).getByText('Alpha')).toBeInTheDocument();
    expect(within(history).getByText('₹80.00')).toBeInTheDocument();

    // Change inputs, then reopen the saved one (with confirmation).
    type(/Actual budget consumption/, '1500');
    expect(within(panel()).getByTestId('action')).toHaveTextContent('INCREASE');
    await user.click(within(history).getByRole('button', { name: /Reopen Alpha/ }));
    await user.click(within(screen.getByRole('alertdialog')).getByRole('button', { name: 'Reopen calculation' }));
    expect(within(panel()).getByTestId('action')).toHaveTextContent('DECREASE');

    await user.click(within(history).getByRole('button', { name: /Clear history/ }));
    await user.click(within(screen.getByRole('alertdialog')).getByRole('button', { name: 'Clear history' }));
    expect(within(history).getByText(/Nothing saved yet/)).toBeInTheDocument();
  });
});

describe('accessibility basics', () => {
  it('mode selector supports arrow keys', async () => {
    const user = userEvent.setup();
    render(<App />);
    const costCap = screen.getByRole('radio', { name: /Cost Cap/ });
    costCap.focus();
    await user.keyboard('{ArrowRight}');
    expect(screen.getByRole('radio', { name: /tROAS/ })).toHaveAttribute('aria-checked', 'true');
    expect(screen.getByRole('radio', { name: /tROAS/ })).toHaveFocus();
  });

  it('links field errors to inputs', () => {
    render(<App />);
    const input = type(/Current Cost Cap bid/, '-4');
    expect(input).toHaveAttribute('aria-invalid', 'true');
    expect(input).toHaveAccessibleDescription(/greater than zero/);
  });
});
