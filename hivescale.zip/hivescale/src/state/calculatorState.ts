/** Application state: both modes are kept independently, plus session history. */
import { initialCostCap, initialTroas, type CostCapFields, type ModeFields, type TroasFields } from '../lib/fields';
import type { Action, Mode, Readiness, RoasFormat } from '../lib/types';
import { convertRoasText } from '../lib/validation';

export interface HistoryEntry {
  id: string;
  timestamp: Date;
  mode: Mode;
  campaignName: string;
  currentBid: string;
  ratio: string;
  action: Action;
  recommendedBid: string;
  readiness: Readiness;
  /** Copy of the inputs so the calculation can be reopened. */
  snapshot: ModeFields;
}

export interface CalculatorState {
  mode: Mode;
  costCap: CostCapFields;
  troas: TroasFields;
  history: HistoryEntry[];
}

export type CalculatorAction =
  | { type: 'setMode'; mode: Mode }
  | { type: 'patchCostCap'; patch: Partial<Omit<CostCapFields, 'mode'>> }
  | { type: 'patchTroas'; patch: Partial<Omit<TroasFields, 'mode' | 'roasFormat'>> }
  | { type: 'setRoasFormat'; format: RoasFormat }
  | { type: 'toggleCheck'; id: string; checked: boolean }
  | { type: 'reset' }
  | { type: 'restore'; snapshot: ModeFields }
  | { type: 'addHistory'; entry: HistoryEntry }
  | { type: 'clearHistory' };

export function initialState(): CalculatorState {
  return { mode: 'costCap', costCap: initialCostCap(), troas: initialTroas(), history: [] };
}

/** Deep-ish clone so history snapshots never share mutable objects with live state. */
export function cloneFields<T extends ModeFields>(fields: T): T {
  return { ...fields, checklist: { ...fields.checklist }, simulation: { ...fields.simulation } };
}

export function calculatorReducer(state: CalculatorState, action: CalculatorAction): CalculatorState {
  switch (action.type) {
    case 'setMode':
      return { ...state, mode: action.mode };
    case 'patchCostCap':
      return { ...state, costCap: { ...state.costCap, ...action.patch } };
    case 'patchTroas':
      return { ...state, troas: { ...state.troas, ...action.patch } };
    case 'setRoasFormat': {
      const t = state.troas;
      if (t.roasFormat === action.format) return state;
      const conv = (v: string) => convertRoasText(v, t.roasFormat, action.format);
      return {
        ...state,
        troas: {
          ...t,
          roasFormat: action.format,
          minRoas: conv(t.minRoas),
          achievedRoas: conv(t.achievedRoas),
          limitMin: conv(t.limitMin),
          limitMax: conv(t.limitMax),
        },
      };
    }
    case 'toggleCheck': {
      const key = state.mode;
      const current = state[key];
      const next = { ...current, checklist: { ...current.checklist, [action.id]: action.checked } };
      return { ...state, [key]: next } as CalculatorState;
    }
    case 'reset':
      return state.mode === 'costCap'
        ? { ...state, costCap: initialCostCap() }
        : { ...state, troas: initialTroas() };
    case 'restore': {
      const snap = cloneFields(action.snapshot);
      return snap.mode === 'costCap'
        ? { ...state, mode: 'costCap', costCap: snap }
        : { ...state, mode: 'troas', troas: snap };
    }
    case 'addHistory':
      return { ...state, history: [action.entry, ...state.history].slice(0, 50) };
    case 'clearHistory':
      return { ...state, history: [] };
    default:
      return state;
  }
}
