import { useEffect, useRef, useState } from 'react';

/**
 * Enables sticky positioning only on wide screens and only while the element
 * fits in the viewport, so it never overlaps content or needs an inner scroll.
 */
export function useStickyIfFits<T extends HTMLElement>(minWidth = 1024, margin = 32) {
  const ref = useRef<T>(null);
  const [sticky, setSticky] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof window === 'undefined') return;
    const update = () => {
      const fits = el.scrollHeight + margin <= window.innerHeight;
      setSticky(window.innerWidth >= minWidth && fits);
    };
    update();
    window.addEventListener('resize', update);
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(update) : null;
    ro?.observe(el);
    return () => {
      window.removeEventListener('resize', update);
      ro?.disconnect();
    };
  }, [minWidth, margin]);
  return { ref, sticky };
}
