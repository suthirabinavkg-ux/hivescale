import { useCallback, useMemo, useReducer, useState } from 'react';
import { AdjustSection } from './components/AdjustSection';
import { Breakdown } from './components/Breakdown';
import { ConfirmDialog, type ConfirmRequest } from './components/ConfirmDialog';
import { Header } from './components/Header';
import { HistoryPanel } from './components/HistoryPanel';
import { InputsColumn } from './components/InputsColumn';
import { RecommendationPanel } from './components/RecommendationPanel';
import { Segmented } from './components/Segmented';
import { Toast, type ToastMessage } from './components/Toast';
import { evaluate } from './lib/evaluate';
import { buildCsv, buildSummaryText, copyText, csvFilename, downloadText } from './lib/exporters';
import { hasMeaningfulData, periodLabel } from './lib/fields';
import { formatRatio, formatTimestamp } from './lib/format';
import { MODE_LABEL } from './lib/rules';
import type { Mode } from './lib/types';
import { useStickyIfFits } from './state/useStickyIfFits';
import { calculatorReducer, cloneFields, initialState, type CalculatorState, type HistoryEntry } from './state/calculatorState';

let toastSeq = 0;
let historySeq = 0;

export default function App({ initial }: { initial?: CalculatorState }) {
  const [state, dispatch] = useReducer(calculatorReducer, initial ?? initialState());
  const [confirm, setConfirm] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [printedAt, setPrintedAt] = useState<Date>(() => new Date());

  const results = useStickyIfFits<HTMLElement>();
  const fields = state.mode === 'costCap' ? state.costCap : state.troas;
  const evaluation = useMemo(() => evaluate(fields), [fields]);

  const notify = useCallback((text: string, tone: ToastMessage['tone'] = 'success') => {
    setToast({ id: ++toastSeq, text, tone });
  }, []);
  const clearToast = useCallback(() => setToast(null), []);

  const onCommon = (patch: { campaignName?: string; market?: string; period?: string }) =>
    state.mode === 'costCap' ? dispatch({ type: 'patchCostCap', patch }) : dispatch({ type: 'patchTroas', patch });

  const onReset = () => {
    const doReset = () => {
      dispatch({ type: 'reset' });
      notify(`${MODE_LABEL[state.mode]} calculator reset`);
    };
    if (!hasMeaningfulData(fields)) return doReset();
    setConfirm({
      title: `Reset the ${MODE_LABEL[state.mode]} calculator?`,
      body: 'This clears the inputs, best-practice checks, bid limits and simulation settings for this mode. Session history is kept.',
      confirmLabel: 'Reset calculator',
      tone: 'danger',
      onConfirm: doReset,
    });
  };

  const onCopy = async () => {
    const ok = await copyText(buildSummaryText(evaluation, fields));
    notify(ok ? 'Recommendation copied' : 'Couldn’t copy. Your browser blocked clipboard access.', ok ? 'success' : 'error');
  };

  const onExport = () => {
    downloadText(csvFilename(fields), buildCsv(evaluation, fields));
    notify('CSV exported');
  };

  const onPrint = () => {
    setPrintedAt(new Date());
    // Let React paint the print header timestamp before the dialog opens.
    window.setTimeout(() => window.print(), 0);
  };

  const onSave = () => {
    const r = evaluation.result;
    if (!r) return;
    const entry: HistoryEntry = {
      id: `h${++historySeq}`,
      timestamp: new Date(),
      mode: fields.mode,
      campaignName: fields.campaignName.trim(),
      currentBid: evaluation.format.bid(r.currentBid),
      ratio: formatRatio(r.ratio),
      action: r.action,
      recommendedBid: evaluation.format.bid(r.finalBid),
      readiness: evaluation.readiness,
      snapshot: cloneFields(fields),
    };
    dispatch({ type: 'addHistory', entry });
    notify('Saved to session history');
  };

  const onReopen = (entry: HistoryEntry) => {
    const target = entry.mode === 'costCap' ? state.costCap : state.troas;
    const doRestore = () => {
      dispatch({ type: 'restore', snapshot: entry.snapshot });
      notify(`Reopened ${entry.campaignName || 'calculation'} from ${formatTimestamp(entry.timestamp)}`);
      const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      document.getElementById('calculator')?.scrollIntoView?.({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    };
    if (!hasMeaningfulData(target)) return doRestore();
    setConfirm({
      title: 'Replace the current inputs?',
      body: `Reopening this saved calculation replaces what’s currently in the ${MODE_LABEL[entry.mode]} calculator.`,
      confirmLabel: 'Reopen calculation',
      onConfirm: doRestore,
    });
  };

  const onClearHistory = () =>
    setConfirm({
      title: 'Clear session history?',
      body: `This removes all ${state.history.length} saved calculation${state.history.length === 1 ? '' : 's'}. Current inputs aren’t affected.`,
      confirmLabel: 'Clear history',
      tone: 'danger',
      onConfirm: () => {
        dispatch({ type: 'clearHistory' });
        notify('Session history cleared');
      },
    });

  return (
    <>
      <a href="#calculator" className="skip-link">
        Skip to calculator
      </a>
      <Header />
      <main className="page" id="main">
        <div className="print-only print-head">
          <p>
            <strong>HiveScale bid recommendation</strong>
          </p>
          <p>
            {MODE_LABEL[fields.mode]}
            {fields.campaignName.trim() ? `, ${fields.campaignName.trim()}` : ''}
            {periodLabel(fields.period) ? `, ${periodLabel(fields.period)}` : ''}. Printed {formatTimestamp(printedAt)}.
          </p>
        </div>

        <div className="page-head">
          <h1>Bid Optimization Calculator</h1>
          <p>Calculate your next bid with consistent, data-backed guidance.</p>
        </div>

        <div className="mode-switch no-print" id="calculator" tabIndex={-1}>
          <Segmented<Mode>
            label="Campaign type"
            size="large"
            value={state.mode}
            onChange={(mode) => dispatch({ type: 'setMode', mode })}
            options={[
              { value: 'costCap', label: 'Cost Cap', description: 'Spend ÷ (bid × conversions)' },
              { value: 'troas', label: 'tROAS', description: 'Minimum ROAS bid ÷ achieved ROAS' },
            ]}
          />
        </div>

        <div className="workspace">
          <div className="workspace__inputs">
            <InputsColumn
              fields={fields}
              evaluation={evaluation}
              onCommon={onCommon}
              onCostCap={(patch) => dispatch({ type: 'patchCostCap', patch })}
              onTroas={(patch) => dispatch({ type: 'patchTroas', patch })}
              onRoasFormat={(format) => dispatch({ type: 'setRoasFormat', format })}
              onToggleCheck={(id, checked) => dispatch({ type: 'toggleCheck', id, checked })}
              onReset={onReset}
            />
          </div>
          <aside className="workspace__results" aria-label="Results" ref={results.ref} data-sticky={results.sticky}>
            <RecommendationPanel
              fields={fields}
              evaluation={evaluation}
              onCopy={onCopy}
              onExport={onExport}
              onPrint={onPrint}
              onSave={onSave}
            />
            <Breakdown fields={fields} evaluation={evaluation} key={fields.mode} />
          </aside>
        </div>

        <AdjustSection
          fields={fields}
          evaluation={evaluation}
          onLimits={(patch) =>
            state.mode === 'costCap' ? dispatch({ type: 'patchCostCap', patch }) : dispatch({ type: 'patchTroas', patch })
          }
          onSimulation={(patch) => {
            const simulation = { ...fields.simulation, ...patch };
            return state.mode === 'costCap'
              ? dispatch({ type: 'patchCostCap', patch: { simulation } })
              : dispatch({ type: 'patchTroas', patch: { simulation } });
          }}
        />

        <HistoryPanel entries={state.history} onReopen={onReopen} onClear={onClearHistory} />
      </main>
      <footer className="app-footer no-print">
        <p>
          HiveScale by HiveMinds. Runs entirely in your browser: nothing you enter is stored permanently or sent anywhere.
        </p>
      </footer>
      <ConfirmDialog request={confirm} onClose={() => setConfirm(null)} />
      <Toast toast={toast} onDone={clearToast} />
    </>
  );
}
