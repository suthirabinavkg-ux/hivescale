export function HiveMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <path d="M16 3.5l10.8 6.25v12.5L16 28.5 5.2 22.25V9.75z" fill="none" stroke="#D9A441" strokeWidth="2.2" strokeLinejoin="round" />
      <path d="M10.5 19.5l4.2-4.2 2.8 2.8 4.2-4.6" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Header() {
  return (
    <header className="app-header">
      <div className="app-header__inner">
        <a className="brand" href="/" aria-label="HiveScale by HiveMinds, home">
          <HiveMark />
          <span className="brand__name">HiveScale</span>
          <span className="brand__by">by HiveMinds</span>
        </a>
        <p className="app-header__tagline">Make every bid count.</p>
      </div>
    </header>
  );
}
