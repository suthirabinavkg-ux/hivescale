import { FolderOpen, History, Trash2 } from 'lucide-react';
import { ACTION_LABEL, MODE_LABEL } from '../lib/rules';
import { formatTime } from '../lib/format';
import type { HistoryEntry } from '../state/calculatorState';
import { ReadinessBadge } from './ReadinessBadge';

interface HistoryProps {
  entries: HistoryEntry[];
  onReopen: (entry: HistoryEntry) => void;
  onClear: () => void;
}

export function HistoryPanel({ entries, onReopen, onClear }: HistoryProps) {
  return (
    <section className="history no-print" aria-labelledby="history-heading">
      <div className="history__head">
        <div>
          <h2 id="history-heading">
            <History size={18} aria-hidden="true" />
            Session history
          </h2>
          <p className="muted">
            Saved calculations from this tab only. They stay in memory and disappear when you close or reload the page.
          </p>
        </div>
        {entries.length > 0 && (
          <button type="button" className="btn btn--quiet btn--small" onClick={onClear}>
            <Trash2 size={14} aria-hidden="true" />
            Clear history
          </button>
        )}
      </div>
      {entries.length === 0 ? (
        <p className="history__empty">
          Nothing saved yet. Use <strong>Save to history</strong> on a recommendation to keep a snapshot you can reopen later in
          this session.
        </p>
      ) : (
        <div className="table-scroll">
          <table className="history__table">
            <thead>
              <tr>
                <th scope="col">Saved</th>
                <th scope="col">Campaign</th>
                <th scope="col">Type</th>
                <th scope="col" className="num">Current bid</th>
                <th scope="col" className="num">Ratio</th>
                <th scope="col">Action</th>
                <th scope="col" className="num">Recommended</th>
                <th scope="col">Readiness</th>
                <th scope="col">
                  <span className="sr-only">Reopen</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id}>
                  <td className="num">{formatTime(e.timestamp)}</td>
                  <td className="history__name">{e.campaignName || <span className="muted">Untitled</span>}</td>
                  <td>{MODE_LABEL[e.mode]}</td>
                  <td className="num">{e.currentBid}</td>
                  <td className="num">{e.ratio}</td>
                  <td>
                    <span className={`action-text action-text--${e.action}`}>{ACTION_LABEL[e.action]}</span>
                  </td>
                  <td className="num">{e.recommendedBid}</td>
                  <td>
                    <ReadinessBadge readiness={e.readiness} />
                  </td>
                  <td>
                    <button
                      type="button"
                      className="btn btn--quiet btn--small"
                      onClick={() => onReopen(e)}
                      aria-label={`Reopen ${e.campaignName || 'untitled'} calculation saved at ${formatTime(e.timestamp)}`}
                    >
                      <FolderOpen size={14} aria-hidden="true" />
                      Reopen
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
