import { formatRatio } from '../lib/format';
import { ACTION_BY_BAND, LOWER_THRESHOLD, UPPER_THRESHOLD } from '../lib/rules';
import type { Action, Band, Mode } from '../lib/types';

const ZONE_NAME: Record<Action, string> = { increase: 'Increase', decrease: 'Decrease', maintain: 'Maintain' };

/** Scale end grows with the ratio so the marker always has room, capped for readability. */
export function scaleMax(ratio: number): number {
  const needed = Math.ceil(ratio * 1.15 * 2) / 2;
  return Math.min(Math.max(2, needed), 4);
}

export function RatioScale({ ratio, mode, band }: { ratio: number; mode: Mode; band: Band }) {
  const max = scaleMax(ratio);
  const pos = (v: number) => `${(Math.min(v, max) / max) * 100}%`;
  const offScale = ratio > max;
  const share = Math.min(ratio, max) / max;
  const zones: Band[] = ['below', 'within', 'above'];
  const action = ACTION_BY_BAND[mode][band];
  const label = `Billing ratio ${formatRatio(ratio)}. ${ZONE_NAME[action]} zone. Maintain range is ${LOWER_THRESHOLD.toFixed(2)} to ${UPPER_THRESHOLD.toFixed(2)}.`;
  return (
    <figure className="ratio-scale" role="img" aria-label={label}>
      <div className="ratio-scale__track">
        {zones.map((z) => {
          const start = z === 'below' ? 0 : z === 'within' ? LOWER_THRESHOLD : UPPER_THRESHOLD;
          const end = z === 'below' ? LOWER_THRESHOLD : z === 'within' ? UPPER_THRESHOLD : max;
          const zoneAction = ACTION_BY_BAND[mode][z];
          return (
            <div
              key={z}
              className={`ratio-scale__zone zone--${zoneAction}${z === band ? ' is-active' : ''}`}
              style={{ left: pos(start), width: `calc(${pos(end)} - ${pos(start)})` }}
            >
              <span className="ratio-scale__zone-label">{ZONE_NAME[zoneAction]}</span>
            </div>
          );
        })}
        <div
          className={`ratio-scale__marker${share > 0.85 ? ' is-end' : share < 0.12 ? ' is-start' : ''}`}
          style={{ left: offScale ? '100%' : pos(ratio) }}
        >
          <span className="ratio-scale__value">
            {formatRatio(ratio)}
            {offScale ? ' ›' : ''}
          </span>
        </div>
      </div>
      <div className="ratio-scale__ticks" aria-hidden="true">
        <span style={{ left: '0%' }}>0</span>
        <span style={{ left: pos(LOWER_THRESHOLD) }}>{LOWER_THRESHOLD.toFixed(2)}</span>
        <span style={{ left: pos(UPPER_THRESHOLD) }}>{UPPER_THRESHOLD.toFixed(2)}</span>
        <span style={{ left: '100%' }}>{max.toFixed(1)}{offScale ? '+' : ''}</span>
      </div>
    </figure>
  );
}
