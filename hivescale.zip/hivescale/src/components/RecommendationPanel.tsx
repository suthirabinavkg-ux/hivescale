import { ArrowDownRight, ArrowUpRight, BookmarkPlus, Copy, Download, Equal, Printer, ShieldAlert } from 'lucide-react';
import type { Evaluation } from '../lib/evaluate';
import { actionDetail, explanation, limitSentence, thresholdText } from '../lib/explain';
import { periodLabel, type ModeFields } from '../lib/fields';
import { formatPercent, formatRatio } from '../lib/format';
import { ACTION_LABEL, MODE_LABEL } from '../lib/rules';
import type { Action } from '../lib/types';
import { RatioScale } from './RatioScale';
import { ReadinessBadge } from './ReadinessBadge';

const ACTION_ICON: Record<Action, typeof Equal> = {
  increase: ArrowUpRight,
  decrease: ArrowDownRight,
  maintain: Equal,
};

export const DISCLAIMER =
  'This is a decision-support recommendation based on the configured HiveMinds rules. Review campaign conditions and platform constraints before applying the change.';

interface PanelProps {
  fields: ModeFields;
  evaluation: Evaluation;
  onCopy: () => void;
  onExport: () => void;
  onPrint: () => void;
  onSave: () => void;
}

export function RecommendationPanel({ fields, evaluation, onCopy, onExport, onPrint, onSave }: PanelProps) {
  const r = evaluation.result;
  const f = evaluation.format;
  const isTroas = fields.mode === 'troas';
  const disabledNote = !r ? 'Available once a recommendation is calculated.' : undefined;

  return (
    <section
      className={`panel${r ? ` panel--${r.action}` : ' panel--empty'}`}
      aria-labelledby="rec-heading"
      aria-live="polite"
      aria-atomic="false"
    >
      <div className="panel__top">
        <h2 id="rec-heading">Recommendation</h2>
        <span className="mode-tag">{MODE_LABEL[fields.mode]}</span>
        <ReadinessBadge readiness={evaluation.readiness} />
      </div>

      {r ? (
        <>
          <div className="action-band" data-testid="action">
            <span className="action-band__icon" aria-hidden="true">
              {(() => {
                const Icon = ACTION_ICON[r.action];
                return <Icon size={20} strokeWidth={2.4} />;
              })()}
            </span>
            <span className="action-band__word">{ACTION_LABEL[r.action]}</span>
            <span className="action-band__detail">{actionDetail(r.mode, r.action)}</span>
          </div>

          <div className="headline">
            <p className="headline__label">{isTroas ? 'Recommended minimum ROAS bid' : 'Recommended bid'}</p>
            <p
              className={`headline__value${f.bid(r.finalBid).length > 13 ? ' headline__value--long' : ''}`}
              data-testid="recommended-bid"
            >
              {f.bid(r.finalBid)}
            </p>
            <p className="headline__change">
              <span>{f.change(r.absoluteChange)}</span>
              <span className="headline__pct">{formatPercent(r.percentChange)}</span>
              <span className="headline__from">from {f.bid(r.currentBid)}</span>
            </p>
          </div>

          <p className="explanation" data-testid="explanation">
            {explanation(evaluation, false)}
          </p>

          <Comparison current={r.currentBid} next={r.finalBid} format={f.bid} action={r.action} />

          {r.limitApplied && (
            <div className="note note--limit" role="note">
              <ShieldAlert size={16} aria-hidden="true" />
              <p>
                <strong>Bid limit applied.</strong> {limitSentence(evaluation)}
              </p>
            </div>
          )}

          <div className="ratio-block">
            <div className="ratio-block__head">
              <span>Billing ratio</span>
              <strong data-testid="billing-ratio">{formatRatio(r.ratio)}</strong>
            </div>
            <RatioScale ratio={r.ratio} mode={r.mode} band={r.band} />
          </div>

          <dl className="facts">
            <div>
              <dt>{isTroas ? 'Current minimum ROAS bid' : 'Current bid'}</dt>
              <dd>{f.bid(r.currentBid)}</dd>
            </div>
            {evaluation.troas && (
              <div>
                <dt>Achieved ROAS</dt>
                <dd>{f.bid(evaluation.troas.achievedRoas)}</dd>
              </div>
            )}
            <div>
              <dt>Applicable threshold</dt>
              <dd>{thresholdText(r.band)}</dd>
            </div>
            <div>
              <dt>Adjustment</dt>
              <dd>{formatPercent(r.adjustment)}</dd>
            </div>
            <div>
              <dt>Campaign type</dt>
              <dd>{MODE_LABEL[r.mode]}</dd>
            </div>
            {periodLabel(fields.period) && (
              <div>
                <dt>Measurement period</dt>
                <dd>{periodLabel(fields.period)}</dd>
              </div>
            )}
            {fields.campaignName.trim() && (
              <div className="facts__wide">
                <dt>Campaign</dt>
                <dd className="wrap">
                  {fields.campaignName.trim()}
                  {fields.market.trim() ? `, ${fields.market.trim()}` : ''}
                </dd>
              </div>
            )}
          </dl>

          {evaluation.readiness === 'provisional' ? (
            <div className="note note--provisional" role="note">
              <p>
                <strong>Provisional: Complete best-practice checks first.</strong>{' '}
                {evaluation.checklist.pending.length} of {evaluation.checklist.total} still open:
              </p>
              <ul>
                {evaluation.checklist.pending.map((p) => (
                  <li key={p.id}>{p.label}</li>
                ))}
              </ul>
              <a href="#checklist" className="link">
                Go to best-practice checks
              </a>
            </div>
          ) : (
            <div className="note note--ready" role="note">
              <p>
                <strong>Ready for review.</strong> All best-practice checks are marked complete.
              </p>
            </div>
          )}
        </>
      ) : (
        <EmptyState evaluation={evaluation} />
      )}

      <p className="disclaimer">{DISCLAIMER}</p>

      <div className="action-bar no-print" role="group" aria-label="Recommendation actions">
        <button type="button" className="btn btn--primary" onClick={onCopy} disabled={!r} title={disabledNote}>
          <Copy size={15} aria-hidden="true" />
          Copy summary
        </button>
        <button type="button" className="btn" onClick={onExport} disabled={!r} title={disabledNote}>
          <Download size={15} aria-hidden="true" />
          Export CSV
        </button>
        <button type="button" className="btn" onClick={onPrint}>
          <Printer size={15} aria-hidden="true" />
          Print
        </button>
        <button type="button" className="btn" onClick={onSave} disabled={!r} title={disabledNote}>
          <BookmarkPlus size={15} aria-hidden="true" />
          Save to history
        </button>
      </div>
      {!r && <p className="action-bar__note no-print">Copy, export and save become available once a recommendation is calculated.</p>}
    </section>
  );
}

function Comparison({
  current,
  next,
  format,
  action,
}: {
  current: number;
  next: number;
  format: (v: number) => string;
  action: Action;
}) {
  const max = Math.max(current, next) || 1;
  return (
    <div className="compare" aria-label="Current and recommended bid comparison" role="group">
      <div className="compare__row">
        <span className="compare__label">Current</span>
        <span className="compare__bar">
          <span className="compare__fill compare__fill--current" style={{ width: `${(current / max) * 100}%` }} />
        </span>
        <span className="compare__value">{format(current)}</span>
      </div>
      <div className="compare__row">
        <span className="compare__label">Recommended</span>
        <span className="compare__bar">
          <span className={`compare__fill compare__fill--${action}`} style={{ width: `${(next / max) * 100}%` }} />
        </span>
        <span className="compare__value">{format(next)}</span>
      </div>
    </div>
  );
}

function EmptyState({ evaluation }: { evaluation: Evaluation }) {
  if (evaluation.readiness === 'invalid') {
    return (
      <div className="empty empty--invalid" data-testid="empty-state">
        <p className="empty__title">No recommendation yet</p>
        <p>Fix the following to calculate the billing ratio:</p>
        <ul>
          {evaluation.blockers.map((b) => (
            <li key={b}>{b}</li>
          ))}
        </ul>
      </div>
    );
  }
  return (
    <div className="empty" data-testid="empty-state">
      <p className="empty__title">Enter your campaign numbers</p>
      <p>The billing ratio and recommended bid appear here as soon as the required fields are filled in.</p>
      {evaluation.missing.length > 0 && (
        <>
          <p className="empty__sub">Still needed:</p>
          <ul>
            {evaluation.missing.map((m) => (
              <li key={m}>{m}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
