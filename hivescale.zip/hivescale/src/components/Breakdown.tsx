import { useId, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import type { Evaluation } from '../lib/evaluate';
import { breakdown } from '../lib/explain';
import type { ModeFields } from '../lib/fields';

/** "How was this calculated?" disclosure. Always expanded in print. */
export function Breakdown({ fields, evaluation }: { fields: ModeFields; evaluation: Evaluation }) {
  const [open, setOpen] = useState(false);
  const bodyId = useId();
  const steps = breakdown(evaluation, fields);
  return (
    <section className="disclosure" aria-label="Calculation breakdown">
      <h2 className="disclosure__heading">
        <button
          type="button"
          className="disclosure__toggle"
          aria-expanded={open}
          aria-controls={bodyId}
          onClick={() => setOpen((o) => !o)}
        >
          <span>How was this calculated?</span>
          <ChevronDown size={18} aria-hidden="true" className="disclosure__chev" />
        </button>
      </h2>
      <div id={bodyId} className="disclosure__body" hidden={!open}>
        {steps.length === 0 ? (
          <p className="muted">The step-by-step calculation appears once the required inputs are valid.</p>
        ) : (
          <ol className="steps" data-testid="breakdown">
            {steps.map((s) => (
              <li key={s.label} className={s.emphasis ? 'steps__item is-final' : 'steps__item'}>
                <span className="steps__label">{s.label}</span>
                <span className="steps__value">{s.value}</span>
                {s.detail && <span className="steps__detail">{s.detail}</span>}
              </li>
            ))}
          </ol>
        )}
      </div>
    </section>
  );
}
