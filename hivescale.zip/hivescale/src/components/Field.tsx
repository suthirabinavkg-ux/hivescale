import { useId, type ReactNode } from 'react';
import { AlertCircle, Info } from 'lucide-react';

interface FieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  hint?: ReactNode;
  error?: string;
  warning?: string;
  prefix?: string;
  suffix?: string;
  inputMode?: 'decimal' | 'numeric' | 'text';
  placeholder?: string;
  numeric?: boolean;
  maxLength?: number;
  name?: string;
  className?: string;
  showOptional?: boolean;
}

/** Labelled text input with hint, error and warning messages wired to ARIA. */
export function Field({
  label,
  value,
  onChange,
  required,
  hint,
  error,
  warning,
  prefix,
  suffix,
  inputMode = 'text',
  placeholder,
  numeric,
  maxLength,
  name,
  className,
  showOptional = true,
}: FieldProps) {
  const id = useId();
  const hintId = `${id}-hint`;
  const msgId = `${id}-msg`;
  const describedBy = [hint ? hintId : null, error || warning ? msgId : null].filter(Boolean).join(' ') || undefined;
  return (
    <div className={['field', error ? 'field--error' : '', className ?? ''].join(' ').trim()}>
      <label htmlFor={id} className="field__label">
        {label}
        {required ? <span className="field__req"> required</span> : showOptional ? <span className="field__opt"> optional</span> : null}
      </label>
      <div className={['field__control', numeric ? 'field__control--num' : ''].join(' ')}>
        {prefix && <span className="field__affix" aria-hidden="true">{prefix}</span>}
        <input
          id={id}
          name={name}
          type="text"
          inputMode={inputMode}
          autoComplete="off"
          spellCheck={false}
          value={value}
          placeholder={placeholder}
          maxLength={maxLength ?? 64}
          aria-invalid={error ? true : undefined}
          aria-required={required || undefined}
          aria-describedby={describedBy}
          onChange={(e) => onChange(e.target.value)}
        />
        {suffix && <span className="field__affix field__affix--end" aria-hidden="true">{suffix}</span>}
      </div>
      {hint && (
        <p id={hintId} className="field__hint">
          {hint}
        </p>
      )}
      {error ? (
        <p id={msgId} className="field__msg field__msg--error">
          <AlertCircle size={14} aria-hidden="true" />
          <span>{error}</span>
        </p>
      ) : warning ? (
        <p id={msgId} className="field__msg field__msg--warn">
          <Info size={14} aria-hidden="true" />
          <span>{warning}</span>
        </p>
      ) : null}
    </div>
  );
}

interface SelectFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: ReadonlyArray<{ value: string; label: string }>;
  hint?: string;
}

export function SelectField({ label, value, onChange, options, hint }: SelectFieldProps) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id} className="field__label">
        {label}
        <span className="field__opt"> optional</span>
      </label>
      <div className="field__control field__control--select">
        <select id={id} value={value} onChange={(e) => onChange(e.target.value)} aria-describedby={hint ? `${id}-hint` : undefined}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>
      {hint && (
        <p id={`${id}-hint`} className="field__hint">
          {hint}
        </p>
      )}
    </div>
  );
}
