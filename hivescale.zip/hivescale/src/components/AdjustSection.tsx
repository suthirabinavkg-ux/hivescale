import { FlaskConical, SlidersHorizontal } from 'lucide-react';
import { simulate } from '../lib/engine';
import type { Evaluation } from '../lib/evaluate';
import type { ModeFields, SimulationSettings } from '../lib/fields';
import { currencySymbol, formatPercent } from '../lib/format';
import { RULE_ADJUSTMENT } from '../lib/rules';
import { parseNumber } from '../lib/validation';
import { Field } from './Field';
import { Segmented } from './Segmented';

const SENSITIVITY_STEPS = [0.05, 0.1, 0.15, 0.2, 0.25];
const QUICK_PERCENTS = ['10', '15', '20'];

interface AdjustProps {
  fields: ModeFields;
  evaluation: Evaluation;
  onLimits: (patch: { limitMin?: string; limitMax?: string }) => void;
  onSimulation: (patch: Partial<SimulationSettings>) => void;
}

export function AdjustSection({ fields, evaluation, onLimits, onSimulation }: AdjustProps) {
  return (
    <section className="adjust no-print-sim" aria-labelledby="adjust-heading">
      <div className="adjust__head">
        <h2 id="adjust-heading">Limits and what-if scenarios</h2>
        <p className="muted">Optional. Neither changes the billing ratio or the official action.</p>
      </div>
      <div className="adjust__grid">
        <BidLimits fields={fields} evaluation={evaluation} onLimits={onLimits} />
        <Simulator fields={fields} evaluation={evaluation} onSimulation={onSimulation} />
      </div>
    </section>
  );
}

function BidLimits({ fields, evaluation, onLimits }: Omit<AdjustProps, 'onSimulation'>) {
  const r = evaluation.result;
  const f = evaluation.format;
  const isTroas = fields.mode === 'troas';
  const unitPrefix = fields.mode === 'costCap' ? currencySymbol(fields.currency) : undefined;
  const suffix = isTroas ? (fields.mode === 'troas' && fields.roasFormat === 'percentage' ? '%' : 'x') : undefined;
  return (
    <div className="card" aria-labelledby="limits-heading" role="region">
      <h3 id="limits-heading" className="card__title">
        <SlidersHorizontal size={16} aria-hidden="true" />
        Bid limits
      </h3>
      <p className="card__note">
        Leave empty for no limit. Limits only cap the final proposed bid; HiveScale doesn’t assume any platform limits.
      </p>
      <div className="grid-2">
        <Field
          label="Minimum bid"
          numeric
          inputMode="decimal"
          prefix={unitPrefix}
          suffix={suffix}
          value={fields.limitMin}
          onChange={(v) => onLimits({ limitMin: v })}
          error={evaluation.errors.limitMin}
        />
        <Field
          label="Maximum bid"
          numeric
          inputMode="decimal"
          prefix={unitPrefix}
          suffix={suffix}
          value={fields.limitMax}
          onChange={(v) => onLimits({ limitMax: v })}
          error={evaluation.errors.limitMax}
        />
      </div>
      {r && (
        <div className="limit-status" data-testid="limit-status">
          {r.limitApplied && r.limitValue !== null ? (
            <dl className="limit-steps">
              <div>
                <dt>Official rule result</dt>
                <dd>{f.bid(r.ruleBid)}</dd>
              </div>
              <div>
                <dt>Your {r.limitApplied === 'max' ? 'maximum' : 'minimum'} limit</dt>
                <dd>{f.bid(r.limitValue)}</dd>
              </div>
              <div className="is-final">
                <dt>Final proposed bid</dt>
                <dd>{f.bid(r.finalBid)}</dd>
              </div>
            </dl>
          ) : !evaluation.limits.valid ? (
            <p className="muted">Limits aren’t applied until they’re valid.</p>
          ) : evaluation.limits.min !== undefined || evaluation.limits.max !== undefined ? (
            <p className="muted">The official result of {f.bid(r.ruleBid)} is within your limits, so nothing changes.</p>
          ) : null}
        </div>
      )}
    </div>
  );
}

function Simulator({ fields, evaluation, onSimulation }: Omit<AdjustProps, 'onLimits'>) {
  const r = evaluation.result;
  const f = evaluation.format;
  const sim = fields.simulation;
  const parsed = parseNumber(sim.percent, { label: 'Adjustment', min: 0, exclusive: true });
  let pctError = parsed.kind === 'error' ? parsed.message : undefined;
  if (parsed.kind === 'ok' && parsed.value > 90) pctError = 'Use an adjustment between 1% and 90%.';
  const percent = parsed.kind === 'ok' && !pctError ? parsed.value / 100 : null;
  const direction =
    sim.direction === 'auto' ? (r?.action === 'decrease' ? 'decrease' : 'increase') : sim.direction;
  const limits = evaluation.limits.valid ? evaluation.limits : {};

  return (
    <div className="card card--sim" role="region" aria-labelledby="sim-heading">
      <h3 id="sim-heading" className="card__title">
        <FlaskConical size={16} aria-hidden="true" />
        What-if scenario
        <span className="sim-tag">Simulation</span>
      </h3>
      <p className="card__note">
        Mathematical previews of the bid value only. They don’t predict conversions, spend, CPA or ROAS, and never replace
        the official {Math.round(RULE_ADJUSTMENT * 100)}% recommendation.
      </p>

      {!r ? (
        <p className="muted">Enter valid inputs to preview alternative adjustments.</p>
      ) : (
        <>
          <div className="sim-controls">
            <Segmented<'increase' | 'decrease'>
              label="Simulated direction"
              value={direction}
              onChange={(v) => onSimulation({ direction: v })}
              options={[
                { value: 'decrease', label: 'Decrease' },
                { value: 'increase', label: 'Increase' },
              ]}
            />
            <div className="quick" role="group" aria-label="Quick percentages">
              {QUICK_PERCENTS.map((p) => (
                <button
                  key={p}
                  type="button"
                  className={sim.percent === p ? 'chip is-on' : 'chip'}
                  aria-pressed={sim.percent === p}
                  onClick={() => onSimulation({ percent: p })}
                >
                  {p}%
                </button>
              ))}
            </div>
            <Field
              label="Adjustment"
              numeric
              inputMode="decimal"
              suffix="%"
              value={sim.percent}
              onChange={(v) => onSimulation({ percent: v })}
              error={pctError}
              showOptional={false}
              className="field--compact"
            />
          </div>

          {percent !== null && (
            <SimResult
              currentBid={r.currentBid}
              direction={direction}
              percent={percent}
              limits={limits}
              format={f}
              officialBid={r.finalBid}
            />
          )}

          <div className="sens-scroll">
          <table className="sens" aria-describedby="sens-caption">
            <caption id="sens-caption">
              Sensitivity preview from the current bid of {f.bid(r.currentBid)}. The official rule result is marked.
            </caption>
            <thead>
              <tr>
                <th scope="col">Adjustment</th>
                <th scope="col">Decrease to</th>
                <th scope="col">Increase to</th>
              </tr>
            </thead>
            <tbody>
              {SENSITIVITY_STEPS.map((step) => {
                const dec = simulate(r.currentBid, 'decrease', step, limits);
                const inc = simulate(r.currentBid, 'increase', step, limits);
                const isRuleRow = dec.isRuleDefault;
                const cell = (s: typeof dec) => {
                  const official = isRuleRow && r.action === s.direction;
                  return (
                    <td className={official ? 'is-official' : undefined}>
                      <span className="num">{f.bid(s.bid)}</span>
                      {official && <span className="official-tag">Official</span>}
                      {s.outsideLimit && (
                        <span className="limit-tag">beyond {s.outsideLimit === 'max' ? 'max' : 'min'}</span>
                      )}
                    </td>
                  );
                };
                return (
                  <tr key={step}>
                    <th scope="row">{Math.round(step * 100)}%</th>
                    {cell(dec)}
                    {cell(inc)}
                  </tr>
                );
              })}
            </tbody>
          </table>
          </div>
          {r.action === 'maintain' && (
            <p className="muted small">The official recommendation is to maintain the bid at {f.bid(r.currentBid)}.</p>
          )}
        </>
      )}
    </div>
  );
}

function SimResult({
  currentBid,
  direction,
  percent,
  limits,
  format,
  officialBid,
}: {
  currentBid: number;
  direction: 'increase' | 'decrease';
  percent: number;
  limits: { min?: number; max?: number };
  format: Evaluation['format'];
  officialBid: number;
}) {
  const s = simulate(currentBid, direction, percent, limits);
  return (
    <div className="sim-result" data-testid="simulation">
      <div>
        <span className="sim-result__label">
          What-if: {direction} by {formatPercent(percent).replace(/^[+−]/, '')}
        </span>
        <span className="sim-result__value">{format.bid(s.bid)}</span>
        <span className="sim-result__change">{format.change(s.absoluteChange)}</span>
      </div>
      <div className="sim-result__official">
        <span className="sim-result__label">Official recommendation</span>
        <span className="sim-result__value sim-result__value--quiet">{format.bid(officialBid)}</span>
      </div>
      {s.outsideLimit && (
        <p className="sim-result__warn">
          This simulated bid is beyond your {s.outsideLimit === 'max' ? 'maximum' : 'minimum'} limit.
        </p>
      )}
    </div>
  );
}
