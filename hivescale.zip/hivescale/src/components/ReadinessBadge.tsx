import { AlertTriangle, CheckCircle2, CircleDashed, XCircle } from 'lucide-react';
import type { Readiness } from '../lib/types';

const META: Record<Readiness, { text: string; Icon: typeof CheckCircle2 }> = {
  ready: { text: 'Ready for review', Icon: CheckCircle2 },
  provisional: { text: 'Provisional', Icon: AlertTriangle },
  incomplete: { text: 'Incomplete', Icon: CircleDashed },
  invalid: { text: 'Invalid', Icon: XCircle },
};

export function ReadinessBadge({ readiness }: { readiness: Readiness }) {
  const { text, Icon } = META[readiness];
  return (
    <span className={`badge badge--${readiness}`} data-testid="readiness">
      <Icon size={14} aria-hidden="true" />
      {text}
    </span>
  );
}
