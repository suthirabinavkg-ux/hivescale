import { RotateCcw } from 'lucide-react';
import { CHECKLIST } from '../lib/checklist';
import type { Evaluation } from '../lib/evaluate';
import { PERIOD_OPTIONS, type CostCapFields, type ModeFields, type TroasFields } from '../lib/fields';
import { CURRENCIES, currencySymbol, type CurrencyCode } from '../lib/format';
import type { RoasFormat } from '../lib/types';
import { MODE_LABEL } from '../lib/rules';
import { Field, SelectField } from './Field';
import { Segmented } from './Segmented';

interface CommonPatch {
  campaignName?: string;
  market?: string;
  period?: string;
}

interface InputsColumnProps {
  fields: ModeFields;
  evaluation: Evaluation;
  onCommon: (patch: CommonPatch) => void;
  onCostCap: (patch: Partial<Omit<CostCapFields, 'mode'>>) => void;
  onTroas: (patch: Partial<Omit<TroasFields, 'mode' | 'roasFormat'>>) => void;
  onRoasFormat: (format: RoasFormat) => void;
  onToggleCheck: (id: string, checked: boolean) => void;
  onReset: () => void;
}

export function InputsColumn(props: InputsColumnProps) {
  const { fields, evaluation, onCommon, onReset } = props;
  return (
    <div className="sheet" aria-label={`${MODE_LABEL[fields.mode]} inputs`} role="group">
      <section className="sheet__section" aria-labelledby="campaign-heading">
        <div className="section-head">
          <h2 id="campaign-heading">Campaign</h2>
          <button type="button" className="btn btn--quiet btn--small" onClick={onReset}>
            <RotateCcw size={14} aria-hidden="true" />
            Reset {MODE_LABEL[fields.mode]}
          </button>
        </div>
        <div className="grid-2">
          <Field
            label="Campaign name"
            value={fields.campaignName}
            onChange={(v) => onCommon({ campaignName: v })}
            maxLength={160}
            placeholder="e.g. IN Remit Q4 Prospecting"
          />
          <Field
            label="Market or corridor"
            value={fields.market}
            onChange={(v) => onCommon({ market: v })}
            maxLength={80}
            placeholder="e.g. UAE → India"
          />
          <SelectField
            label="Measurement period"
            value={fields.period}
            onChange={(v) => onCommon({ period: v })}
            options={PERIOD_OPTIONS}
          />
          {fields.mode === 'costCap' && (
            <SelectField
              label="Currency"
              value={fields.currency}
              onChange={(v) => props.onCostCap({ currency: v as CurrencyCode })}
              options={CURRENCIES.map((c) => ({ value: c.code, label: `${c.code}, ${c.name}` }))}
            />
          )}
        </div>
      </section>

      {fields.mode === 'costCap' ? (
        <CostCapSection fields={fields} evaluation={evaluation} onChange={props.onCostCap} />
      ) : (
        <TroasSection fields={fields} evaluation={evaluation} onChange={props.onTroas} onFormat={props.onRoasFormat} />
      )}

      <ChecklistSection fields={fields} evaluation={evaluation} onToggle={props.onToggleCheck} />
    </div>
  );
}

function CostCapSection({
  fields,
  evaluation,
  onChange,
}: {
  fields: CostCapFields;
  evaluation: Evaluation;
  onChange: (patch: Partial<Omit<CostCapFields, 'mode'>>) => void;
}) {
  const sym = currencySymbol(fields.currency);
  return (
    <section className="sheet__section" aria-labelledby="perf-heading">
      <div className="section-head">
        <h2 id="perf-heading">Cost Cap performance</h2>
      </div>
      <p className="section-note">
        Use spend and conversions from the same measurement period, in the same currency as the bid.
      </p>
      <div className="grid-2">
        <Field
          label="Current Cost Cap bid"
          required
          numeric
          inputMode="decimal"
          prefix={sym}
          value={fields.bid}
          onChange={(v) => onChange({ bid: v })}
          error={evaluation.errors.bid}
          placeholder="0.00"
        />
        <Field
          label="Actual budget consumption"
          required
          numeric
          inputMode="decimal"
          prefix={sym}
          value={fields.spend}
          onChange={(v) => onChange({ spend: v })}
          error={evaluation.errors.spend}
          hint="Amount spent in the period"
          placeholder="0.00"
        />
        <Field
          label="Conversions"
          required
          numeric
          inputMode="numeric"
          value={fields.conversions}
          onChange={(v) => onChange({ conversions: v })}
          error={evaluation.errors.conversions}
          hint="Whole number"
          placeholder="0"
        />
      </div>
    </section>
  );
}

function TroasSection({
  fields,
  evaluation,
  onChange,
  onFormat,
}: {
  fields: TroasFields;
  evaluation: Evaluation;
  onChange: (patch: Partial<Omit<TroasFields, 'mode' | 'roasFormat'>>) => void;
  onFormat: (format: RoasFormat) => void;
}) {
  const pct = fields.roasFormat === 'percentage';
  return (
    <section className="sheet__section" aria-labelledby="perf-heading">
      <div className="section-head">
        <h2 id="perf-heading">tROAS performance</h2>
      </div>
      <div className="format-row">
        <span className="format-row__label" id="roas-format-label">
          ROAS format
        </span>
        <Segmented<RoasFormat>
          label="ROAS display format"
          value={fields.roasFormat}
          onChange={onFormat}
          options={[
            { value: 'multiplier', label: 'Multiplier', description: '2.5x' },
            { value: 'percentage', label: 'Percentage', description: '250%' },
          ]}
        />
      </div>
      <p className="section-note">
        {pct
          ? 'Enter ROAS as a percentage: 250 means 250%, which equals 2.5x.'
          : 'Enter ROAS as a multiplier: 2.5 means 2.5x, which equals 250%.'}{' '}
        Both values must cover the same measurement period. Switching format converts the values you’ve entered.
      </p>
      <div className="grid-2">
        <Field
          label="Current minimum ROAS bid"
          required
          numeric
          inputMode="decimal"
          suffix={pct ? '%' : 'x'}
          value={fields.minRoas}
          onChange={(v) => onChange({ minRoas: v })}
          error={evaluation.errors.minRoas}
          warning={evaluation.warnings.minRoas}
          hint="The ROAS target set on the campaign"
          placeholder={pct ? '250' : '2.5'}
        />
        <Field
          label="Achieved ROAS"
          required
          numeric
          inputMode="decimal"
          suffix={pct ? '%' : 'x'}
          value={fields.achievedRoas}
          onChange={(v) => onChange({ achievedRoas: v })}
          error={evaluation.errors.achievedRoas}
          warning={evaluation.warnings.achievedRoas}
          hint="Actual ROAS over the period"
          placeholder={pct ? '300' : '3.0'}
        />
      </div>
    </section>
  );
}

function ChecklistSection({
  fields,
  evaluation,
  onToggle,
}: {
  fields: ModeFields;
  evaluation: Evaluation;
  onToggle: (id: string, checked: boolean) => void;
}) {
  const { done, total } = evaluation.checklist;
  return (
    <section className="sheet__section" aria-labelledby="checklist-heading" id="checklist">
      <div className="section-head">
        <h2 id="checklist-heading">Best-practice checks</h2>
        <span className={done === total ? 'count count--done' : 'count'} aria-live="polite">
          {done} of {total} complete
        </span>
      </div>
      <p className="section-note">
        HiveMinds guidance applies only once these are in place. Completing them doesn’t guarantee results.
      </p>
      <div className="progress" aria-hidden="true">
        <span style={{ width: `${(done / total) * 100}%` }} />
      </div>
      <ul className="checklist">
        {CHECKLIST.map((item) => {
          const id = `check-${fields.mode}-${item.id}`;
          const checked = Boolean(fields.checklist[item.id]);
          return (
            <li key={item.id} className={checked ? 'checklist__item is-checked' : 'checklist__item'}>
              <input id={id} type="checkbox" checked={checked} onChange={(e) => onToggle(item.id, e.target.checked)} aria-describedby={`${id}-hint`} />
              <label htmlFor={id}>
                <span className="checklist__label">{item.label}</span>
                <span className="checklist__hint" id={`${id}-hint`}>
                  {item.hint}
                </span>
              </label>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
