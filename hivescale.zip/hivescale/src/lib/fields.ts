/** Raw (as-typed) form state for each mode. Kept as strings so typing is lossless. */
import { emptyChecklist } from './checklist';
import type { CurrencyCode } from './format';
import type { Mode, RoasFormat } from './types';

export const PERIOD_OPTIONS = [
  { value: '', label: 'Not specified' },
  { value: '1', label: '1 day' },
  { value: '3', label: '3 days' },
  { value: '7', label: '7 days' },
  { value: '14', label: '14 days' },
  { value: '28', label: '28 days' },
  { value: '30', label: '30 days' },
] as const;

export function periodLabel(value: string): string | null {
  const match = PERIOD_OPTIONS.find((p) => p.value === value);
  return match && match.value !== '' ? match.label : null;
}

export interface SimulationSettings {
  percent: string;
  /** 'auto' follows the official action (increase when the action is maintain). */
  direction: 'auto' | 'increase' | 'decrease';
}

interface CommonFields {
  campaignName: string;
  market: string;
  period: string;
  checklist: Record<string, boolean>;
  limitMin: string;
  limitMax: string;
  simulation: SimulationSettings;
}

export interface CostCapFields extends CommonFields {
  mode: 'costCap';
  currency: CurrencyCode;
  bid: string;
  spend: string;
  conversions: string;
}

export interface TroasFields extends CommonFields {
  mode: 'troas';
  roasFormat: RoasFormat;
  minRoas: string;
  achievedRoas: string;
}

export type ModeFields = CostCapFields | TroasFields;

function common(): CommonFields {
  return {
    campaignName: '',
    market: '',
    period: '',
    checklist: emptyChecklist(),
    limitMin: '',
    limitMax: '',
    simulation: { percent: '10', direction: 'auto' },
  };
}

export function initialCostCap(): CostCapFields {
  return { ...common(), mode: 'costCap', currency: 'INR', bid: '', spend: '', conversions: '' };
}

export function initialTroas(): TroasFields {
  return { ...common(), mode: 'troas', roasFormat: 'multiplier', minRoas: '', achievedRoas: '' };
}

export function initialFields(mode: Mode): ModeFields {
  return mode === 'costCap' ? initialCostCap() : initialTroas();
}

/** True when the user has entered anything worth confirming before discarding. */
export function hasMeaningfulData(fields: ModeFields): boolean {
  const base =
    fields.campaignName.trim() !== '' ||
    fields.market.trim() !== '' ||
    fields.period !== '' ||
    fields.limitMin.trim() !== '' ||
    fields.limitMax.trim() !== '' ||
    Object.values(fields.checklist).some(Boolean);
  if (fields.mode === 'costCap') {
    return base || [fields.bid, fields.spend, fields.conversions].some((v) => v.trim() !== '');
  }
  return base || [fields.minRoas, fields.achievedRoas].some((v) => v.trim() !== '');
}
