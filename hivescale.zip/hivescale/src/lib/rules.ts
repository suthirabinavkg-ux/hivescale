/**
 * HiveMinds optimization rules. This file is the single source of truth for
 * thresholds, actions and the default adjustment. Change rules here only.
 */
import type { Action, Band, Mode } from './types';

/** Billing ratio strictly below this value takes the mode's "below" action. */
export const LOWER_THRESHOLD = 0.8;
/** Billing ratio strictly above this value takes the mode's "above" action. */
export const UPPER_THRESHOLD = 1.2;
/** Official adjustment applied by the rules (20%). */
export const RULE_ADJUSTMENT = 0.2;

/**
 * Tolerance used only when comparing a ratio with a threshold, so that values
 * that are mathematically on the boundary (e.g. 0.96 / 1.2) but suffer from
 * binary floating-point error (0.7999999999999999) are treated as exactly 0.80.
 */
export const BOUNDARY_TOLERANCE = 1e-9;

export const ACTION_BY_BAND: Record<Mode, Record<Band, Action>> = {
  // Cost Cap: Billing Ratio = Actual Budget Consumption / (Bid × Conversions)
  costCap: { below: 'decrease', within: 'maintain', above: 'increase' },
  // tROAS: Billing Ratio = Minimum ROAS Bid / Achieved ROAS
  troas: { below: 'increase', within: 'maintain', above: 'decrease' },
};

export const MODE_LABEL: Record<Mode, string> = {
  costCap: 'Cost Cap',
  troas: 'tROAS',
};

export const FORMULA_TEXT: Record<Mode, string> = {
  costCap: 'Billing ratio = Actual budget consumption ÷ (Current bid × Conversions)',
  troas: 'Billing ratio = Minimum ROAS bid ÷ Achieved ROAS',
};

export const ACTION_LABEL: Record<Action, string> = {
  increase: 'INCREASE',
  maintain: 'MAINTAIN',
  decrease: 'DECREASE',
};
