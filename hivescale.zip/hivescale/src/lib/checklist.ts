/**
 * Best-practice checks required before applying a billing-ratio recommendation.
 * Update this list as HiveMinds' official best practices evolve. Item ids are
 * stored in state, so keep them stable when only the wording changes.
 */
export interface ChecklistItem {
  id: string;
  label: string;
  hint: string;
}

export const CHECKLIST: readonly ChecklistItem[] = [
  {
    id: 'tracking',
    label: 'Conversion tracking and measurement have been verified',
    hint: 'Events fire correctly and attribution settings match the reporting view.',
  },
  {
    id: 'period',
    label: 'The measurement period is appropriate and consistent',
    hint: 'All inputs come from the same date range.',
  },
  {
    id: 'volume',
    label: 'Sufficient conversion data is available to evaluate performance',
    hint: 'A handful of conversions can swing the ratio sharply.',
  },
  {
    id: 'setup',
    label: 'Campaign setup and optimization settings have been reviewed',
    hint: 'Objective, optimization event, audiences and placements are as intended.',
  },
  {
    id: 'delivery',
    label: 'Budget constraints and delivery issues have been checked',
    hint: 'No budget caps, learning-phase limits or disapprovals are distorting spend.',
  },
  {
    id: 'changes',
    label: 'Recent major campaign changes have been considered',
    hint: 'Edits made during the period may not be reflected yet.',
  },
] as const;

export function emptyChecklist(): Record<string, boolean> {
  return Object.fromEntries(CHECKLIST.map((item) => [item.id, false]));
}
