/**
 * Pure, deterministic calculation engine. No UI, no formatting, no state.
 * All values are kept at full precision; rounding happens only for display.
 */
import {
  ACTION_BY_BAND,
  BOUNDARY_TOLERANCE,
  LOWER_THRESHOLD,
  RULE_ADJUSTMENT,
  UPPER_THRESHOLD,
} from './rules';
import type { Action, Band, LimitSide, Mode } from './types';

/** Cost Cap: spend / (bid × conversions). Returns null when undefined. */
export function costCapBillingRatio(spend: number, bid: number, conversions: number): number | null {
  if (![spend, bid, conversions].every(Number.isFinite)) return null;
  if (spend < 0 || bid <= 0 || conversions < 0) return null;
  const denominator = bid * conversions;
  if (!(denominator > 0) || !Number.isFinite(denominator)) return null;
  const ratio = spend / denominator;
  return Number.isFinite(ratio) ? ratio : null;
}

/** tROAS: minimum ROAS bid / achieved ROAS (both as multipliers). */
export function troasBillingRatio(minRoasBid: number, achievedRoas: number): number | null {
  if (!Number.isFinite(minRoasBid) || !Number.isFinite(achievedRoas)) return null;
  if (minRoasBid <= 0 || achievedRoas <= 0) return null;
  const ratio = minRoasBid / achievedRoas;
  return Number.isFinite(ratio) ? ratio : null;
}

/** 0.80 and 1.20 are inclusive in the Maintain band. */
export function classifyRatio(ratio: number): Band {
  if (ratio < LOWER_THRESHOLD - BOUNDARY_TOLERANCE) return 'below';
  if (ratio > UPPER_THRESHOLD + BOUNDARY_TOLERANCE) return 'above';
  return 'within';
}

export function actionFor(mode: Mode, band: Band): Action {
  return ACTION_BY_BAND[mode][band];
}

/** Multiplier applied to the current bid for an action and adjustment size. */
export function bidMultiplier(action: Action, adjustment: number = RULE_ADJUSTMENT): number {
  if (action === 'increase') return 1 + adjustment;
  if (action === 'decrease') return 1 - adjustment;
  return 1;
}

/** Signed adjustment as a fraction (+0.2, -0.2 or 0). */
export function signedAdjustment(action: Action, adjustment: number = RULE_ADJUSTMENT): number {
  if (action === 'increase') return adjustment;
  if (action === 'decrease') return -adjustment;
  return 0;
}

export interface BidLimits {
  min?: number;
  max?: number;
}

export interface LimitOutcome {
  value: number;
  applied: LimitSide | null;
  limitValue: number | null;
}

/** Applies user limits to a proposed bid. Never touches the ratio or action. */
export function applyBidLimits(value: number, limits: BidLimits = {}): LimitOutcome {
  const { min, max } = limits;
  if (min !== undefined && max !== undefined && min > max) {
    return { value, applied: null, limitValue: null };
  }
  if (min !== undefined && value < min) return { value: min, applied: 'min', limitValue: min };
  if (max !== undefined && value > max) return { value: max, applied: 'max', limitValue: max };
  return { value, applied: null, limitValue: null };
}

export interface Recommendation {
  mode: Mode;
  ratio: number;
  band: Band;
  action: Action;
  /** Signed fraction applied by the rule (+0.2 / -0.2 / 0). */
  adjustment: number;
  /** 1.2, 0.8 or 1. */
  multiplier: number;
  currentBid: number;
  /** Bid calculated by the official rule, before limits. */
  ruleBid: number;
  /** Bid after user limits (equals ruleBid when no limit applies). */
  finalBid: number;
  limitApplied: LimitSide | null;
  limitValue: number | null;
  /** finalBid − currentBid */
  absoluteChange: number;
  /** (finalBid − currentBid) / currentBid */
  percentChange: number;
}

export function recommend(mode: Mode, ratio: number, currentBid: number, limits?: BidLimits): Recommendation {
  const band = classifyRatio(ratio);
  const action = actionFor(mode, band);
  const multiplier = bidMultiplier(action);
  const ruleBid = currentBid * multiplier;
  const limited = applyBidLimits(ruleBid, limits);
  const finalBid = limited.value;
  return {
    mode,
    ratio,
    band,
    action,
    adjustment: signedAdjustment(action),
    multiplier,
    currentBid,
    ruleBid,
    finalBid,
    limitApplied: limited.applied,
    limitValue: limited.limitValue,
    absoluteChange: finalBid - currentBid,
    percentChange: currentBid > 0 ? (finalBid - currentBid) / currentBid : 0,
  };
}

export interface Simulation {
  percent: number; // e.g. 0.1 for 10%
  direction: Exclude<Action, 'maintain'>;
  bid: number;
  absoluteChange: number;
  isRuleDefault: boolean;
  outsideLimit: LimitSide | null;
}

/** What-if preview. Pure math on the current bid; never a performance prediction. */
export function simulate(
  currentBid: number,
  direction: Exclude<Action, 'maintain'>,
  percent: number,
  limits: BidLimits = {},
): Simulation {
  const bid = currentBid * bidMultiplier(direction, percent);
  let outsideLimit: LimitSide | null = null;
  if (limits.min !== undefined && bid < limits.min) outsideLimit = 'min';
  else if (limits.max !== undefined && bid > limits.max) outsideLimit = 'max';
  return {
    percent,
    direction,
    bid,
    absoluteChange: bid - currentBid,
    isRuleDefault: Math.abs(percent - RULE_ADJUSTMENT) < 1e-12,
    outsideLimit,
  };
}
