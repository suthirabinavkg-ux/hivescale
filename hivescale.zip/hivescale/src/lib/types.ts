export type Mode = 'costCap' | 'troas';
export type Action = 'increase' | 'maintain' | 'decrease';
/** Where the billing ratio falls relative to the HiveMinds thresholds. */
export type Band = 'below' | 'within' | 'above';
export type Readiness = 'incomplete' | 'invalid' | 'provisional' | 'ready';
export type RoasFormat = 'multiplier' | 'percentage';
export type LimitSide = 'min' | 'max';
