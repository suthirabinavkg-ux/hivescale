import { describe, expect, it } from 'vitest';
import { evaluate } from '../evaluate';
import { breakdown, explanation } from '../explain';
import { buildCsv, buildSummaryText, csvCell, csvFilename } from '../exporters';
import { initialCostCap, initialTroas, type CostCapFields, type TroasFields } from '../fields';
import { CHECKLIST } from '../checklist';

const allChecked = () => Object.fromEntries(CHECKLIST.map((c) => [c.id, true]));
const cc = (p: Partial<CostCapFields>): CostCapFields => ({ ...initialCostCap(), ...p });
const tr = (p: Partial<TroasFields>): TroasFields => ({ ...initialTroas(), ...p });

describe('readiness states', () => {
  it('incomplete when required inputs are missing', () => {
    const e = evaluate(cc({ bid: '100' }));
    expect(e.readiness).toBe('incomplete');
    expect(e.result).toBeNull();
    expect(e.missing).toEqual(['Actual budget consumption', 'Conversions']);
  });
  it('invalid on bad values even if others are missing', () => {
    expect(evaluate(cc({ bid: '-5' })).readiness).toBe('invalid');
  });
  it('invalid with zero conversions and explains why', () => {
    const e = evaluate(cc({ bid: '100', spend: '500', conversions: '0' }));
    expect(e.readiness).toBe('invalid');
    expect(e.result).toBeNull();
    expect(e.errors.conversions).toMatch(/zero conversions/i);
  });
  it('invalid with zero achieved ROAS', () => {
    const e = evaluate(tr({ minRoas: '2', achievedRoas: '0' }));
    expect(e.readiness).toBe('invalid');
    expect(e.errors.achievedRoas).toMatch(/zero/);
  });
  it('provisional when checks are incomplete, ready when complete', () => {
    const base = { bid: '100', spend: '650', conversions: '10' };
    const e1 = evaluate(cc(base));
    expect(e1.readiness).toBe('provisional');
    expect(e1.result?.ratio).toBeCloseTo(0.65, 12);
    expect(e1.checklist.pending).toHaveLength(CHECKLIST.length);
    expect(evaluate(cc({ ...base, checklist: allChecked() })).readiness).toBe('ready');
  });
  it('invalid limits do not block the recommendation', () => {
    const e = evaluate(cc({ bid: '100', spend: '1500', conversions: '10', limitMin: '200', limitMax: '100' }));
    expect(e.readiness).toBe('provisional');
    expect(e.errors.limitMax).toMatch(/greater than or equal/);
    expect(e.result?.finalBid).toBeCloseTo(120, 10);
    expect(e.result?.limitApplied).toBeNull();
  });
});

describe('tROAS percentage inputs', () => {
  it('gives the same result as multiplier inputs', () => {
    const pct = evaluate(tr({ roasFormat: 'percentage', minRoas: '270', achievedRoas: '200' }));
    const mul = evaluate(tr({ minRoas: '2.7', achievedRoas: '2' }));
    expect(pct.result?.ratio).toBeCloseTo(mul.result!.ratio, 12);
    expect(pct.result?.action).toBe('decrease');
    expect(pct.format.bid(pct.result!.finalBid)).toBe('216%');
    expect(mul.format.bid(mul.result!.finalBid)).toBe('2.16x');
  });
  it('applies ROAS limits in the selected format', () => {
    const e = evaluate(tr({ roasFormat: 'percentage', minRoas: '200', achievedRoas: '400', limitMax: '230' }));
    expect(e.result?.action).toBe('increase');
    expect(e.result?.ruleBid).toBeCloseTo(2.4, 12);
    expect(e.result?.finalBid).toBeCloseTo(2.3, 12);
  });
});

describe('explanations and breakdown match the result', () => {
  it('Cost Cap example from the brief', () => {
    const fields = cc({ bid: '100', spend: '650', conversions: '10' });
    const e = evaluate(fields);
    expect(explanation(e)).toBe(
      'Your billing ratio is 0.65, below the 0.80 threshold. Based on the HiveMinds Cost Cap guidance, the recommended action is to reduce the current bid by 20%.',
    );
    const steps = breakdown(e, fields);
    expect(steps.find((s) => s.label === 'Substituted values')?.value).toBe('₹650.00 ÷ (₹100.00 × 10)');
    expect(steps.find((s) => s.label === 'Recommended bid formula')?.value).toBe('₹100.00 × 0.80');
    expect(steps.find((s) => s.label === 'Rule-based recommended bid')?.value).toBe(e.format.bid(e.result!.finalBid));
  });
  it('tROAS example from the brief', () => {
    const e = evaluate(tr({ minRoas: '2.7', achievedRoas: '2' }));
    expect(explanation(e)).toBe(
      'Your billing ratio is 1.35, above the 1.20 threshold. Based on the HiveMinds tROAS guidance, the recommended action is to reduce the minimum ROAS bid by 20%.',
    );
  });
  it('shows limit steps and final bid when a limit applies', () => {
    const fields = cc({ bid: '100', spend: '1500', conversions: '10', limitMax: '110' });
    const e = evaluate(fields);
    const steps = breakdown(e, fields);
    expect(steps.at(-1)).toMatchObject({ label: 'Final proposed bid', value: '₹110.00' });
    expect(explanation(e)).toMatch(/maximum bid limit of ₹110.00 changes the proposed bid from the rule-based ₹120.00 to ₹110.00/);
  });
});

describe('exports', () => {
  const fields = cc({ campaignName: '=HYPERLINK("x"), "Q4"', bid: '100', spend: '650', conversions: '10', period: '7' });
  const e = evaluate(fields);
  const now = new Date('2026-10-16T09:30:00Z');

  it('builds a pasteable summary', () => {
    const text = buildSummaryText(e, fields, now);
    expect(text).toContain('Campaign type: Cost Cap');
    expect(text).toContain('Measurement period: 7 days');
    expect(text).toContain('Billing ratio: 0.65 (below 0.80)');
    expect(text).toContain('Recommended action: DECREASE (decrease bid by 20%)');
    expect(text).toContain('Recommended bid: ₹80.00 (−₹20.00, −20%)');
    expect(text).toContain('Readiness: Provisional: Complete best-practice checks first.');
  });

  it('builds a two-row CSV with escaping and formula protection', () => {
    const csv = buildCsv(e, fields, now);
    const [header, values] = csv.trim().split('\r\n');
    expect(header.split(',')).toContain('Billing ratio');
    expect(values).toContain(`"'=HYPERLINK(""x""), ""Q4"""`);
    expect(values).toContain(',100.00,650.00,10,0.65,');
    expect(values).toContain('80.00');
    expect(csvCell('a,b')).toBe('"a,b"');
    expect(csvCell('-20.00')).toBe('-20.00');
  });

  it('names files predictably', () => {
    expect(csvFilename(cc({ campaignName: 'IN Remit / Q4!' }), now)).toBe('hivescale-cost-cap-in-remit-q4-2026-10-16.csv');
    expect(csvFilename(tr({}), now)).toBe('hivescale-troas-2026-10-16.csv');
  });
});
