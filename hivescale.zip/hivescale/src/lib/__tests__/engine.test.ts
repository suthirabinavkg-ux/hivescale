import { describe, expect, it } from 'vitest';
import {
  applyBidLimits,
  classifyRatio,
  costCapBillingRatio,
  recommend,
  simulate,
  troasBillingRatio,
} from '../engine';

describe('Cost Cap billing ratio and rules', () => {
  it('computes spend / (bid × conversions)', () => {
    expect(costCapBillingRatio(6500, 100, 100)).toBeCloseTo(0.65, 12);
  });

  it('below 0.80 → DECREASE by 20%', () => {
    const r = recommend('costCap', costCapBillingRatio(6500, 100, 100)!, 100);
    expect(r.band).toBe('below');
    expect(r.action).toBe('decrease');
    expect(r.multiplier).toBe(0.8);
    expect(r.ruleBid).toBeCloseTo(80, 10);
    expect(r.absoluteChange).toBeCloseTo(-20, 10);
    expect(r.percentChange).toBeCloseTo(-0.2, 12);
  });

  it('float-noisy 0.80 (0.24 / (0.1 × 3)) is still MAINTAIN', () => {
    const noisy = costCapBillingRatio(0.24, 0.1, 3)!;
    expect(noisy).toBeLessThan(0.8);
    expect(classifyRatio(noisy)).toBe('within');
  });

  it('exactly 0.80 → MAINTAIN', () => {
    const ratio = costCapBillingRatio(800, 100, 10)!;
    expect(ratio).toBe(0.8);
    const r = recommend('costCap', ratio, 100);
    expect(r.action).toBe('maintain');
    expect(r.finalBid).toBe(100);
    expect(r.percentChange).toBe(0);
  });

  it('inside the range → MAINTAIN', () => {
    expect(recommend('costCap', costCapBillingRatio(1000, 100, 10)!, 100).action).toBe('maintain');
  });

  it('exactly 1.20 → MAINTAIN', () => {
    const ratio = costCapBillingRatio(1200, 100, 10)!;
    expect(recommend('costCap', ratio, 100).action).toBe('maintain');
  });

  it('above 1.20 → INCREASE by 20%', () => {
    const r = recommend('costCap', costCapBillingRatio(1300, 100, 10)!, 100);
    expect(r.action).toBe('increase');
    expect(r.ruleBid).toBeCloseTo(120, 10);
  });

  it('zero conversions gives no ratio', () => {
    expect(costCapBillingRatio(500, 100, 0)).toBeNull();
  });

  it('zero spend with a valid denominator is ratio 0 → DECREASE', () => {
    const ratio = costCapBillingRatio(0, 100, 5)!;
    expect(ratio).toBe(0);
    expect(recommend('costCap', ratio, 100).action).toBe('decrease');
  });

  it('rejects negative and non-finite inputs', () => {
    expect(costCapBillingRatio(-1, 100, 5)).toBeNull();
    expect(costCapBillingRatio(100, -5, 5)).toBeNull();
    expect(costCapBillingRatio(100, 0, 5)).toBeNull();
    expect(costCapBillingRatio(NaN, 100, 5)).toBeNull();
    expect(costCapBillingRatio(100, Infinity, 5)).toBeNull();
  });

  it('handles decimal bids and very large numbers', () => {
    const r = recommend('costCap', costCapBillingRatio(123.45, 12.345, 10)!, 12.345);
    expect(r.ratio).toBeCloseTo(1, 12);
    expect(r.action).toBe('maintain');
    const big = costCapBillingRatio(1e12, 1e6, 1e5)!;
    expect(big).toBeCloseTo(10, 9);
    expect(recommend('costCap', big, 1e6).ruleBid).toBeCloseTo(1.2e6, 3);
  });
});

describe('tROAS billing ratio and rules', () => {
  it('computes min ROAS bid / achieved ROAS', () => {
    expect(troasBillingRatio(2, 2.5)).toBeCloseTo(0.8, 12);
  });

  it('below 0.80 → INCREASE by 20%', () => {
    const r = recommend('troas', troasBillingRatio(2, 4)!, 2);
    expect(r.action).toBe('increase');
    expect(r.ruleBid).toBeCloseTo(2.4, 12);
  });

  it('exactly 0.80 → MAINTAIN, including float-noisy boundary 0.08 / 0.1', () => {
    expect(recommend('troas', troasBillingRatio(2, 2.5)!, 2).action).toBe('maintain');
    const noisy = troasBillingRatio(0.08, 0.1)!;
    expect(noisy).not.toBe(0.8); // 0.7999999999999999 in IEEE-754
    expect(recommend('troas', noisy, 0.08).action).toBe('maintain');
  });

  it('within → MAINTAIN', () => {
    expect(recommend('troas', troasBillingRatio(3, 3)!, 3).action).toBe('maintain');
  });

  it('exactly 1.20 → MAINTAIN', () => {
    expect(recommend('troas', troasBillingRatio(3, 2.5)!, 3).action).toBe('maintain');
  });

  it('above 1.20 → DECREASE by 20%', () => {
    const r = recommend('troas', troasBillingRatio(2.7, 2)!, 2.7);
    expect(r.ratio).toBeCloseTo(1.35, 12);
    expect(r.action).toBe('decrease');
    expect(r.ruleBid).toBeCloseTo(2.16, 12);
  });

  it('zero achieved ROAS gives no ratio', () => {
    expect(troasBillingRatio(2, 0)).toBeNull();
    expect(troasBillingRatio(0, 2)).toBeNull();
  });

  it('never applies Cost Cap direction to tROAS', () => {
    expect(recommend('costCap', 0.5, 100).action).toBe('decrease');
    expect(recommend('troas', 0.5, 2).action).toBe('increase');
    expect(recommend('costCap', 1.5, 100).action).toBe('increase');
    expect(recommend('troas', 1.5, 2).action).toBe('decrease');
  });
});

describe('classification boundaries', () => {
  it.each([
    [0.7999, 'below'],
    [0.8, 'within'],
    [1.0, 'within'],
    [1.2, 'within'],
    [1.2001, 'above'],
  ] as const)('%f → %s', (ratio, band) => {
    expect(classifyRatio(ratio)).toBe(band);
  });
});

describe('bid limits', () => {
  it('caps at maximum without changing ratio or action', () => {
    const r = recommend('costCap', 1.5, 100, { max: 110 });
    expect(r.action).toBe('increase');
    expect(r.ruleBid).toBeCloseTo(120, 10);
    expect(r.finalBid).toBe(110);
    expect(r.limitApplied).toBe('max');
    expect(r.percentChange).toBeCloseTo(0.1, 12);
    expect(r.ratio).toBe(1.5);
  });

  it('raises to minimum', () => {
    const r = recommend('troas', 1.5, 2, { min: 1.8 });
    expect(r.ruleBid).toBeCloseTo(1.6, 12);
    expect(r.finalBid).toBe(1.8);
    expect(r.limitApplied).toBe('min');
  });

  it('leaves the bid alone when within limits', () => {
    const r = recommend('costCap', 1.0, 100, { min: 50, max: 150 });
    expect(r.limitApplied).toBeNull();
    expect(r.finalBid).toBe(100);
  });

  it('ignores contradictory limits', () => {
    expect(applyBidLimits(100, { min: 200, max: 50 })).toEqual({ value: 100, applied: null, limitValue: null });
  });
});

describe('simulations', () => {
  it('previews alternative percentages without touching the official result', () => {
    const official = recommend('costCap', 1.5, 100);
    const s = simulate(100, 'increase', 0.1);
    expect(s.bid).toBeCloseTo(110, 10);
    expect(s.isRuleDefault).toBe(false);
    expect(official.finalBid).toBeCloseTo(120, 10);
    expect(simulate(100, 'decrease', 0.2).isRuleDefault).toBe(true);
  });

  it('flags simulated bids beyond limits', () => {
    expect(simulate(100, 'increase', 0.25, { max: 120 }).outsideLimit).toBe('max');
    expect(simulate(100, 'decrease', 0.25, { min: 80 }).outsideLimit).toBe('min');
  });

  it('is deterministic', () => {
    expect(recommend('troas', 0.73, 2.5)).toEqual(recommend('troas', 0.73, 2.5));
  });
});
