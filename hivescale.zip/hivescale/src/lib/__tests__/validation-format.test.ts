import { describe, expect, it } from 'vitest';
import { convertRoasText, parseNumber, parseRoas } from '../validation';
import { formatMoney, formatPercent, formatRatio, formatRoas, formatSignedMoney, formatSignedRoas } from '../format';

describe('parseNumber', () => {
  const bid = { label: 'Bid', min: 0, exclusive: true };
  it('handles empty, grouping separators and decimals', () => {
    expect(parseNumber('  ', bid)).toEqual({ kind: 'empty' });
    expect(parseNumber('1,00,000.50', bid)).toEqual({ kind: 'ok', value: 100000.5 });
    expect(parseNumber('.5', bid)).toEqual({ kind: 'ok', value: 0.5 });
  });
  it('rejects text, negatives, zero bids, fractions and huge values', () => {
    expect(parseNumber('12abc', bid).kind).toBe('error');
    expect(parseNumber('1e5', bid).kind).toBe('error');
    expect(parseNumber('-5', bid)).toMatchObject({ kind: 'error', message: 'Bid must be greater than zero.' });
    expect(parseNumber('0', bid).kind).toBe('error');
    expect(parseNumber('-1', { label: 'Spend', min: 0 })).toMatchObject({ message: "Spend can't be negative." });
    expect(parseNumber('2.5', { label: 'Conversions', min: 0, integer: true })).toMatchObject({
      message: 'Conversions must be a whole number.',
    });
    expect(parseNumber('9999999999999', bid).kind).toBe('error');
  });
});

describe('ROAS formats', () => {
  it('converts 250% to 2.5x, never 250x', () => {
    expect(parseRoas('250', 'percentage', 'ROAS').multiplier).toBe(2.5);
    expect(parseRoas('250%', 'percentage', 'ROAS').multiplier).toBe(2.5);
    expect(parseRoas('2.5', 'multiplier', 'ROAS').multiplier).toBe(2.5);
    expect(parseRoas('2.5x', 'multiplier', 'ROAS').multiplier).toBe(2.5);
  });
  it('rejects mismatched suffixes', () => {
    expect(parseRoas('250%', 'multiplier', 'ROAS').parsed.kind).toBe('error');
    expect(parseRoas('2.5x', 'percentage', 'ROAS').parsed.kind).toBe('error');
  });
  it('warns about likely format confusion', () => {
    expect(parseRoas('250', 'multiplier', 'ROAS').warning).toMatch(/switch the format to percentage/);
    expect(parseRoas('2.5', 'percentage', 'ROAS').warning).toMatch(/switch the format to multiplier/);
    expect(parseRoas('3', 'multiplier', 'ROAS').warning).toBeUndefined();
  });
  it('converts field text when switching format without float noise', () => {
    expect(convertRoasText('2.5', 'multiplier', 'percentage')).toBe('250');
    expect(convertRoasText('1.1', 'multiplier', 'percentage')).toBe('110');
    expect(convertRoasText('250', 'percentage', 'multiplier')).toBe('2.5');
    expect(convertRoasText('abc', 'percentage', 'multiplier')).toBe('abc');
  });
});

describe('formatting', () => {
  it('formats INR with Indian grouping and 2 decimals', () => {
    expect(formatMoney(100000, 'INR')).toBe('₹1,00,000.00');
    expect(formatSignedMoney(-20, 'INR')).toBe('−₹20.00');
    expect(formatSignedMoney(-0.000001, 'INR')).toBe('₹0.00');
    expect(formatMoney(1500, 'JPY')).toMatch(/1,500$/);
  });
  it('formats ratios to 2dp and never contradicts a boundary', () => {
    expect(formatRatio(0.65)).toBe('0.65');
    expect(formatRatio(0.8)).toBe('0.80');
    expect(formatRatio(0.7951)).toBe('0.795');
    expect(formatRatio(1.2004)).toBe('1.2004');
    expect(formatRatio(0.7999999999999999)).toBe('0.80');
  });
  it('formats ROAS and percentages', () => {
    expect(formatRoas(2.5, 'multiplier')).toBe('2.50x');
    expect(formatRoas(2.5, 'percentage')).toBe('250%');
    expect(formatRoas(3.0000000000000004, 'percentage')).toBe('300%');
    expect(formatSignedRoas(0.5, 'percentage')).toBe('+50 pts');
    expect(formatSignedRoas(-0.4, 'multiplier')).toBe('−0.40x');
    expect(formatPercent(0.2)).toBe('+20%');
    expect(formatPercent(-0.2)).toBe('−20%');
    expect(formatPercent(0)).toBe('0%');
  });
});
