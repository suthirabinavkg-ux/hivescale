/**
 * Turns raw form fields into a complete evaluation: validation, readiness,
 * the official recommendation and value formatters. Used by every surface
 * (panel, breakdown, copy, CSV, history) so they always agree.
 */
import { CHECKLIST, type ChecklistItem } from './checklist';
import { costCapBillingRatio, recommend, troasBillingRatio, type BidLimits, type Recommendation } from './engine';
import type { CostCapFields, ModeFields, TroasFields } from './fields';
import { formatMoney, formatRoas, formatSignedMoney, formatSignedRoas, type CurrencyCode } from './format';
import type { Mode, Readiness, RoasFormat } from './types';
import { parseNumber, parseRoas, type Parsed } from './validation';

export type FieldKey = 'bid' | 'spend' | 'conversions' | 'minRoas' | 'achievedRoas' | 'limitMin' | 'limitMax';

export interface BidFormatter {
  bid: (value: number) => string;
  change: (value: number) => string;
  /** Unit wording for limits and helper text. */
  unit: string;
}

export function bidFormatterFor(fields: ModeFields): BidFormatter {
  if (fields.mode === 'costCap') {
    const code: CurrencyCode = fields.currency;
    return { bid: (v) => formatMoney(v, code), change: (v) => formatSignedMoney(v, code), unit: code };
  }
  const fmt: RoasFormat = fields.roasFormat;
  return {
    bid: (v) => formatRoas(v, fmt),
    change: (v) => formatSignedRoas(v, fmt),
    unit: fmt === 'percentage' ? '%' : 'x',
  };
}

export interface CostCapInputs {
  bid: number;
  spend: number;
  conversions: number;
}
export interface TroasInputs {
  minRoas: number;
  achievedRoas: number;
}

export interface Evaluation {
  mode: Mode;
  readiness: Readiness;
  errors: Partial<Record<FieldKey, string>>;
  warnings: Partial<Record<FieldKey, string>>;
  /** Labels of required fields that are still empty. */
  missing: string[];
  /** Messages that explain why no calculation is possible. */
  blockers: string[];
  checklist: { total: number; done: number; pending: ChecklistItem[] };
  limits: BidLimits & { valid: boolean };
  costCap?: CostCapInputs;
  troas?: TroasInputs;
  result: Recommendation | null;
  format: BidFormatter;
}

function checklistStatus(fields: ModeFields) {
  const pending = CHECKLIST.filter((item) => !fields.checklist[item.id]);
  return { total: CHECKLIST.length, done: CHECKLIST.length - pending.length, pending };
}

function parseLimits(fields: ModeFields, errors: Evaluation['errors']): Evaluation['limits'] {
  const parseOne = (raw: string, key: 'limitMin' | 'limitMax', label: string): number | undefined => {
    if (fields.mode === 'troas') {
      const r = parseRoas(raw, fields.roasFormat, label);
      if (r.parsed.kind === 'error') errors[key] = r.parsed.message;
      return r.parsed.kind === 'ok' ? r.multiplier : undefined;
    }
    const p = parseNumber(raw, { label, min: 0, exclusive: true });
    if (p.kind === 'error') errors[key] = p.message;
    return p.kind === 'ok' ? p.value : undefined;
  };
  const min = parseOne(fields.limitMin, 'limitMin', 'Minimum bid');
  const max = parseOne(fields.limitMax, 'limitMax', 'Maximum bid');
  if (errors.limitMin || errors.limitMax) return { valid: false };
  if (min !== undefined && max !== undefined && min > max) {
    errors.limitMax = 'Maximum bid must be greater than or equal to the minimum bid.';
    return { valid: false };
  }
  return { min, max, valid: true };
}

function readinessFor(
  hasErrors: boolean,
  missing: string[],
  result: Recommendation | null,
  pending: number,
): Readiness {
  if (hasErrors) return 'invalid';
  if (missing.length > 0 || !result) return 'incomplete';
  return pending === 0 ? 'ready' : 'provisional';
}

function evaluateCostCap(fields: CostCapFields): Evaluation {
  const errors: Evaluation['errors'] = {};
  const missing: string[] = [];
  const blockers: string[] = [];
  const take = (key: FieldKey, label: string, p: Parsed): number | undefined => {
    if (p.kind === 'empty') missing.push(label);
    else if (p.kind === 'error') errors[key] = p.message;
    else return p.value;
    return undefined;
  };
  const bid = take('bid', 'Current Cost Cap bid', parseNumber(fields.bid, { label: 'Bid', min: 0, exclusive: true }));
  const spend = take('spend', 'Actual budget consumption', parseNumber(fields.spend, { label: 'Budget consumption', min: 0 }));
  const conversions = take(
    'conversions',
    'Conversions',
    parseNumber(fields.conversions, { label: 'Conversions', min: 0, integer: true }),
  );

  if (conversions === 0) {
    errors.conversions = 'With zero conversions the billing ratio can’t be calculated. Use a period with at least one conversion.';
  }
  const coreErrors = Object.keys(errors).length > 0;
  const limits = parseLimits(fields, errors);
  const checklist = checklistStatus(fields);

  let result: Recommendation | null = null;
  if (!coreErrors && bid !== undefined && spend !== undefined && conversions !== undefined) {
    const ratio = costCapBillingRatio(spend, bid, conversions);
    if (ratio === null) blockers.push('The billing ratio can’t be calculated from these inputs.');
    else result = recommend('costCap', ratio, bid, limits.valid ? limits : undefined);
  }
  if (coreErrors) blockers.push(...Object.entries(errors).filter(([k]) => !k.startsWith('limit')).map(([, m]) => m));

  return {
    mode: 'costCap',
    readiness: readinessFor(coreErrors || blockers.length > 0, missing, result, checklist.pending.length),
    errors,
    warnings: {},
    missing,
    blockers,
    checklist,
    limits,
    costCap: bid !== undefined && spend !== undefined && conversions !== undefined ? { bid, spend, conversions } : undefined,
    result,
    format: bidFormatterFor(fields),
  };
}

function evaluateTroas(fields: TroasFields): Evaluation {
  const errors: Evaluation['errors'] = {};
  const warnings: Evaluation['warnings'] = {};
  const missing: string[] = [];
  const blockers: string[] = [];

  const minR = parseRoas(fields.minRoas, fields.roasFormat, 'Minimum ROAS bid');
  const achR = parseRoas(fields.achievedRoas, fields.roasFormat, 'Achieved ROAS');

  // Zero achieved ROAS gets its own explanation rather than a generic "> 0" error.
  const achievedText = fields.achievedRoas.trim().replace(/[%x×]$/i, '');
  const achievedIsZero = achievedText !== '' && /^[+]?0*(\.0*)?$/.test(achievedText.replace(/[\s,]/g, ''));

  let minRoas: number | undefined;
  let achievedRoas: number | undefined;
  if (minR.parsed.kind === 'empty') missing.push('Current minimum ROAS bid');
  else if (minR.parsed.kind === 'error') errors.minRoas = minR.parsed.message;
  else minRoas = minR.multiplier;

  if (achievedIsZero) {
    errors.achievedRoas = 'With an achieved ROAS of zero the billing ratio can’t be calculated.';
  } else if (achR.parsed.kind === 'empty') missing.push('Achieved ROAS');
  else if (achR.parsed.kind === 'error') errors.achievedRoas = achR.parsed.message;
  else achievedRoas = achR.multiplier;

  if (minR.warning) warnings.minRoas = minR.warning;
  if (achR.warning) warnings.achievedRoas = achR.warning;

  const coreErrors = Object.keys(errors).length > 0;
  const limits = parseLimits(fields, errors);
  const checklist = checklistStatus(fields);

  let result: Recommendation | null = null;
  if (!coreErrors && minRoas !== undefined && achievedRoas !== undefined) {
    const ratio = troasBillingRatio(minRoas, achievedRoas);
    if (ratio === null) blockers.push('The billing ratio can’t be calculated from these inputs.');
    else result = recommend('troas', ratio, minRoas, limits.valid ? limits : undefined);
  }
  if (coreErrors) blockers.push(...Object.entries(errors).filter(([k]) => !k.startsWith('limit')).map(([, m]) => m));

  return {
    mode: 'troas',
    readiness: readinessFor(coreErrors || blockers.length > 0, missing, result, checklist.pending.length),
    errors,
    warnings,
    missing,
    blockers,
    checklist,
    limits,
    troas: minRoas !== undefined && achievedRoas !== undefined ? { minRoas, achievedRoas } : undefined,
    result,
    format: bidFormatterFor(fields),
  };
}

export function evaluate(fields: ModeFields): Evaluation {
  return fields.mode === 'costCap' ? evaluateCostCap(fields) : evaluateTroas(fields);
}
