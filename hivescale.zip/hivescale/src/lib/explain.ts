/**
 * Generates human-readable explanations and the step-by-step breakdown from
 * an evaluation. Every number shown comes from the same Recommendation object.
 */
import type { Evaluation } from './evaluate';
import type { ModeFields } from './fields';
import { formatPlainNumber, formatRatio, formatRoas } from './format';
import { FORMULA_TEXT, LOWER_THRESHOLD, MODE_LABEL, RULE_ADJUSTMENT, UPPER_THRESHOLD } from './rules';
import type { Action, Band, Mode } from './types';

const T_LOW = LOWER_THRESHOLD.toFixed(2);
const T_HIGH = UPPER_THRESHOLD.toFixed(2);
const RULE_PCT = `${Math.round(RULE_ADJUSTMENT * 100)}%`;

export function thresholdText(band: Band): string {
  if (band === 'below') return `Below ${T_LOW}`;
  if (band === 'above') return `Above ${T_HIGH}`;
  return `${T_LOW} to ${T_HIGH}, inclusive`;
}

export function bidNoun(mode: Mode): string {
  return mode === 'costCap' ? 'current bid' : 'minimum ROAS bid';
}

export function actionPhrase(mode: Mode, action: Action): string {
  const noun = bidNoun(mode);
  if (action === 'increase') return `increase the ${noun} by ${RULE_PCT}`;
  if (action === 'decrease') return `reduce the ${noun} by ${RULE_PCT}`;
  return `maintain the ${noun}`;
}

/** Short action line such as "Decrease bid by 20%". */
export function actionSummary(action: Action): string {
  if (action === 'increase') return `Increase bid by ${RULE_PCT}`;
  if (action === 'decrease') return `Decrease bid by ${RULE_PCT}`;
  return 'Maintain bid';
}

export function explanation(evaluation: Evaluation, includeLimit = true): string {
  const r = evaluation.result;
  if (!r) return '';
  const ratio = formatRatio(r.ratio);
  const position =
    r.band === 'below'
      ? `below the ${T_LOW} threshold`
      : r.band === 'above'
        ? `above the ${T_HIGH} threshold`
        : `within the ${T_LOW} to ${T_HIGH} range`;
  let text = `Your billing ratio is ${ratio}, ${position}. Based on the HiveMinds ${MODE_LABEL[r.mode]} guidance, the recommended action is to ${actionPhrase(r.mode, r.action)}.`;
  const limit = includeLimit ? limitSentence(evaluation) : null;
  if (limit) text += ` ${limit}`;
  return text;
}

export function limitSentence(evaluation: Evaluation): string | null {
  const r = evaluation.result;
  if (!r || !r.limitApplied || r.limitValue === null) return null;
  const f = evaluation.format;
  const side = r.limitApplied === 'max' ? 'maximum' : 'minimum';
  return `Your ${side} bid limit of ${f.bid(r.limitValue)} changes the proposed bid from the rule-based ${f.bid(r.ruleBid)} to ${f.bid(r.finalBid)}.`;
}

export interface BreakdownStep {
  label: string;
  value: string;
  detail?: string;
  emphasis?: boolean;
}

export function breakdown(evaluation: Evaluation, fields: ModeFields): BreakdownStep[] {
  const r = evaluation.result;
  if (!r) return [];
  const f = evaluation.format;
  const steps: BreakdownStep[] = [{ label: 'Campaign type', value: MODE_LABEL[r.mode] }];
  steps.push({ label: 'Billing ratio formula', value: FORMULA_TEXT[r.mode] });

  if (r.mode === 'costCap' && evaluation.costCap && fields.mode === 'costCap') {
    const { bid, spend, conversions } = evaluation.costCap;
    const denom = bid * conversions;
    steps.push({
      label: 'Substituted values',
      value: `${f.bid(spend)} ÷ (${f.bid(bid)} × ${formatPlainNumber(conversions, 'en-IN', 0)})`,
      detail: `= ${f.bid(spend)} ÷ ${f.bid(denom)}`,
    });
  } else if (r.mode === 'troas' && evaluation.troas && fields.mode === 'troas') {
    const { minRoas, achievedRoas } = evaluation.troas;
    const fmt = fields.roasFormat;
    steps.push({
      label: 'Substituted values',
      value: `${formatRoas(minRoas, fmt)} ÷ ${formatRoas(achievedRoas, fmt)}`,
      detail:
        fmt === 'percentage'
          ? `Converted to multipliers: ${formatRoas(minRoas, 'multiplier')} ÷ ${formatRoas(achievedRoas, 'multiplier')}`
          : undefined,
    });
  }

  steps.push({
    label: 'Billing ratio',
    value: formatRatio(r.ratio),
    detail: `Unrounded: ${Number(r.ratio.toPrecision(10))}`,
  });
  steps.push({
    label: 'Applicable threshold',
    value: thresholdText(r.band),
    detail: `${MODE_LABEL[r.mode]} rule: ${thresholdText(r.band).toLowerCase()} → ${actionSummary(r.action).toLowerCase()}`,
  });
  steps.push({
    label: 'Applied adjustment',
    value: r.action === 'maintain' ? 'No change (0%)' : `${r.action === 'increase' ? '+' : '−'}${RULE_PCT}`,
  });
  steps.push({
    label: 'Recommended bid formula',
    value: `${f.bid(r.currentBid)} × ${r.multiplier.toFixed(2)}`,
    detail: `Current ${bidNoun(r.mode)} × ${r.multiplier.toFixed(2)}`,
  });
  steps.push({ label: 'Rule-based recommended bid', value: f.bid(r.ruleBid), emphasis: !r.limitApplied });

  if (r.limitApplied && r.limitValue !== null) {
    steps.push({
      label: `Your ${r.limitApplied === 'max' ? 'maximum' : 'minimum'} bid limit`,
      value: f.bid(r.limitValue),
      detail: 'Limits change the proposed bid only, not the billing ratio or action.',
    });
    steps.push({ label: 'Final proposed bid', value: f.bid(r.finalBid), emphasis: true });
  }
  return steps;
}

/** Words after the action label in the panel: "DECREASE" + "bid by 20%". */
export function actionDetail(mode: Mode, action: Action): string {
  const noun = mode === 'costCap' ? 'bid' : 'minimum ROAS bid';
  if (action === 'maintain') return mode === 'costCap' ? 'current bid' : 'minimum ROAS bid';
  return `${noun} by ${RULE_PCT}`;
}
