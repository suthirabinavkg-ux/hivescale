/** Presentation-only formatting. Never feed these strings back into calculations. */
import { BOUNDARY_TOLERANCE, LOWER_THRESHOLD, UPPER_THRESHOLD } from './rules';
import type { RoasFormat } from './types';

export const CURRENCIES = [
  { code: 'INR', name: 'Indian rupee', locale: 'en-IN' },
  { code: 'USD', name: 'US dollar', locale: 'en-US' },
  { code: 'EUR', name: 'Euro', locale: 'en-IE' },
  { code: 'GBP', name: 'British pound', locale: 'en-GB' },
  { code: 'AED', name: 'UAE dirham', locale: 'en-AE' },
  { code: 'SAR', name: 'Saudi riyal', locale: 'en-SA' },
  { code: 'SGD', name: 'Singapore dollar', locale: 'en-SG' },
  { code: 'AUD', name: 'Australian dollar', locale: 'en-AU' },
  { code: 'CAD', name: 'Canadian dollar', locale: 'en-CA' },
  { code: 'IDR', name: 'Indonesian rupiah', locale: 'en-ID' },
  { code: 'JPY', name: 'Japanese yen', locale: 'en-JP' },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]['code'];

export function currencyLocale(code: CurrencyCode): string {
  return CURRENCIES.find((c) => c.code === code)?.locale ?? 'en-US';
}

export function currencySymbol(code: CurrencyCode): string {
  const part = new Intl.NumberFormat(currencyLocale(code), {
    style: 'currency',
    currency: code,
    currencyDisplay: 'narrowSymbol',
  })
    .formatToParts(0)
    .find((p) => p.type === 'currency');
  return part?.value ?? code;
}

const moneyCache = new Map<string, Intl.NumberFormat>();
function moneyFormatter(code: CurrencyCode): Intl.NumberFormat {
  let f = moneyCache.get(code);
  if (!f) {
    f = new Intl.NumberFormat(currencyLocale(code), { style: 'currency', currency: code });
    moneyCache.set(code, f);
  }
  return f;
}

/** Number of minor-unit digits for a currency (2 for INR, 0 for JPY). */
export function currencyDigits(code: CurrencyCode): number {
  return moneyFormatter(code).resolvedOptions().maximumFractionDigits ?? 2;
}

/** Normalises -0 so that "−₹0.00" never appears. */
function clean(value: number): number {
  return Object.is(value, -0) || Math.abs(value) < 1e-12 ? 0 : value;
}

export function formatMoney(value: number, code: CurrencyCode): string {
  return moneyFormatter(code).format(clean(value));
}

export function formatSignedMoney(value: number, code: CurrencyCode): string {
  const v = clean(value);
  const digits = currencyDigits(code);
  if (Math.abs(v) < 0.5 * 10 ** -digits) return formatMoney(0, code);
  const body = formatMoney(Math.abs(v), code);
  return v > 0 ? `+${body}` : `−${body}`;
}

export function formatPlainNumber(value: number, locale = 'en-IN', maxDigits = 2): string {
  return new Intl.NumberFormat(locale, { maximumFractionDigits: maxDigits }).format(clean(value));
}

/**
 * Formats a billing ratio to 2 decimals. If rounding would land exactly on a
 * threshold while the true value is outside the Maintain band (e.g. 0.7951),
 * extra decimals are shown so the display never contradicts the action.
 */
export function formatRatio(ratio: number): string {
  const r = clean(ratio);
  for (let digits = 2; digits <= 6; digits++) {
    const shown = Number(r.toFixed(digits));
    const onLower = Math.abs(shown - LOWER_THRESHOLD) < 1e-12;
    const onUpper = Math.abs(shown - UPPER_THRESHOLD) < 1e-12;
    const trulyLower = Math.abs(r - LOWER_THRESHOLD) <= BOUNDARY_TOLERANCE;
    const trulyUpper = Math.abs(r - UPPER_THRESHOLD) <= BOUNDARY_TOLERANCE;
    if ((onLower && !trulyLower) || (onUpper && !trulyUpper)) continue;
    return r.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: digits });
  }
  return r.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 });
}

/** Signed percentage from a fraction: 0.2 → "+20%". */
export function formatPercent(fraction: number): string {
  const v = clean(fraction) * 100;
  const body = Math.abs(v).toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (Number(body.replace(/,/g, '')) === 0) return '0%';
  return `${v > 0 ? '+' : '−'}${body}%`;
}

/** ROAS from an internal multiplier, in the chosen display format. */
export function formatRoas(multiplier: number, format: RoasFormat): string {
  const m = clean(multiplier);
  if (format === 'percentage') {
    return `${(m * 100).toLocaleString('en-US', { maximumFractionDigits: 2 })}%`;
  }
  return `${m.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}x`;
}

export function formatSignedRoas(multiplier: number, format: RoasFormat): string {
  const m = clean(multiplier);
  const sign = m > 0 ? '+' : m < 0 ? '−' : '';
  if (format === 'percentage') {
    const pts = Math.abs(m * 100).toLocaleString('en-US', { maximumFractionDigits: 2 });
    return pts === '0' ? '0 pts' : `${sign}${pts} pts`;
  }
  const body = Math.abs(m).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return body === '0.00' ? '0.00x' : `${sign}${body}x`;
}

export function formatTimestamp(date: Date): string {
  return new Intl.DateTimeFormat('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

export function formatTime(date: Date): string {
  return new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(date);
}
