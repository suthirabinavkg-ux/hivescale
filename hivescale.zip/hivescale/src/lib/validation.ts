/** Input parsing and validation. Converts raw text into numbers or messages. */
import type { RoasFormat } from './types';

/** Upper bound for any numeric input, to keep calculations and layout sane. */
export const MAX_INPUT_VALUE = 1e12;

export type Parsed =
  | { kind: 'empty' }
  | { kind: 'ok'; value: number }
  | { kind: 'error'; message: string };

const NUMBER_PATTERN = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;

/** Strips grouping separators (1,00,000 or 100 000) and whitespace. */
export function normalizeNumericText(raw: string): string {
  return raw.trim().replace(/[\s,\u00a0\u202f_]/g, '');
}

export interface NumberRules {
  label: string;
  /** Minimum allowed value; `exclusive` makes it a strict bound. */
  min: number;
  exclusive?: boolean;
  integer?: boolean;
}

export function parseNumber(raw: string, rules: NumberRules): Parsed {
  const text = normalizeNumericText(raw);
  if (text === '') return { kind: 'empty' };
  if (!NUMBER_PATTERN.test(text)) {
    return { kind: 'error', message: `${rules.label} must be a number, like 1250 or 12.5.` };
  }
  const value = Number(text);
  if (!Number.isFinite(value)) {
    return { kind: 'error', message: `${rules.label} must be a number.` };
  }
  if (Math.abs(value) > MAX_INPUT_VALUE) {
    return { kind: 'error', message: `${rules.label} is too large. Enter a value up to 1 trillion.` };
  }
  if (rules.exclusive ? value <= rules.min : value < rules.min) {
    if (rules.min === 0) {
      return {
        kind: 'error',
        message: rules.exclusive
          ? `${rules.label} must be greater than zero.`
          : `${rules.label} can't be negative.`,
      };
    }
    return { kind: 'error', message: `${rules.label} must be at least ${rules.min}.` };
  }
  if (rules.integer && !Number.isInteger(value)) {
    return { kind: 'error', message: `${rules.label} must be a whole number.` };
  }
  return { kind: 'ok', value };
}

export interface RoasParsed {
  parsed: Parsed;
  /** Value converted to a multiplier (2.5 for 250%), when parsed is ok. */
  multiplier?: number;
  warning?: string;
}

/**
 * Parses a ROAS value entered in the selected display format and converts it
 * to the internal multiplier representation. 250% → 2.5, never 250x.
 */
export function parseRoas(raw: string, format: RoasFormat, label: string): RoasParsed {
  const trimmed = raw.trim();
  const endsPct = /%$/.test(trimmed);
  const endsX = /[x×]$/i.test(trimmed);

  if (format === 'multiplier' && endsPct) {
    return {
      parsed: {
        kind: 'error',
        message: `${label} is set to multiplier format. Enter 2.5 for 250%, or switch the format to percentage.`,
      },
    };
  }
  if (format === 'percentage' && endsX) {
    return {
      parsed: {
        kind: 'error',
        message: `${label} is set to percentage format. Enter 250 for 2.5x, or switch the format to multiplier.`,
      },
    };
  }
  const core = endsPct || endsX ? trimmed.slice(0, -1) : trimmed;
  const parsed = parseNumber(core, { label, min: 0, exclusive: true });
  if (parsed.kind !== 'ok') return { parsed };

  const multiplier = format === 'percentage' ? parsed.value / 100 : parsed.value;
  let warning: string | undefined;
  if (format === 'multiplier' && parsed.value >= 50) {
    warning = `That's a ${parsed.value}x ROAS. If you meant ${parsed.value}%, switch the format to percentage.`;
  } else if (format === 'percentage' && parsed.value < 10) {
    warning = `That's ${parsed.value}% (${roundForInput(parsed.value / 100)}x). If you meant ${parsed.value}x, switch the format to multiplier.`;
  }
  return { parsed, multiplier, warning };
}

/** Rounds away binary noise (2.5 × 100 = 250.00000000000003) for display in inputs. */
export function roundForInput(value: number): number {
  return Number(value.toPrecision(12));
}

/**
 * Converts the text in a ROAS field when the user switches format, so the
 * meaning of the value is preserved (2.5x ↔ 250%). Invalid text is left as is.
 */
export function convertRoasText(raw: string, from: RoasFormat, to: RoasFormat): string {
  if (from === to) return raw;
  const result = parseRoas(raw, from, 'ROAS');
  if (result.parsed.kind !== 'ok' || result.multiplier === undefined) return raw;
  const next = to === 'percentage' ? result.multiplier * 100 : result.multiplier;
  return String(roundForInput(next));
}
